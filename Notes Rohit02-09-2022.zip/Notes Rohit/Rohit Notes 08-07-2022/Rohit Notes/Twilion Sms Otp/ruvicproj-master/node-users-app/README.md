#### Intro to: Docker + MongoDB + Node.js stack.

*[Video explanation](https://www.youtube.com/watch?v=g5w4Ga1TThI&feature=youtu.be&fbclid=IwAR2fRaNuAs6whbofAOtyFwjBmbZ3wbmJFCfKT3yoY445epso3CATfk1Oubs)*.
