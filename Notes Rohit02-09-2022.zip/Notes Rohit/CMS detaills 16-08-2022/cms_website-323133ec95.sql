-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: sdb-w.hosting.stackcp.net
-- Generation Time: Aug 16, 2022 at 08:12 AM
-- Server version: 10.4.25-MariaDB-log
-- PHP Version: 7.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms_website-323133ec95`
--

-- --------------------------------------------------------

--
-- Table structure for table `smartend_analytics_pages`
--

CREATE TABLE `smartend_analytics_pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visitor_id` int(11) NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `query` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `load_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_analytics_pages`
--

INSERT INTO `smartend_analytics_pages` (`id`, `visitor_id`, `ip`, `title`, `name`, `query`, `load_time`, `date`, `time`, `created_at`, `updated_at`) VALUES
(1, 1, '::1', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://localhost:8181/admin/login', '2.10150599', '2022-08-07', '18:32:48', '2022-08-07 13:02:48', '2022-08-07 13:02:48'),
(2, 1, '::1', 'Dashboard &raquo; Site Title', 'unknown', 'http://localhost:8181/admin', '3.30499291', '2022-08-07', '18:33:03', '2022-08-07 13:03:03', '2022-08-07 13:03:03'),
(3, 1, '::1', 'Site Title', 'unknown', 'http://localhost:8181/', '3.85975409', '2022-08-07', '18:33:13', '2022-08-07 13:03:13', '2022-08-07 13:03:13'),
(4, 1, '::1', 'Dashboard &raquo; General Settings', 'unknown', 'http://localhost:8181/admin/settings', '2.83296108', '2022-08-07', '18:33:38', '2022-08-07 13:03:38', '2022-08-07 13:03:38'),
(5, 1, '::1', 'Dashboard &raquo; Site Menus', 'unknown', 'http://localhost:8181/admin/menus', '1.78836894', '2022-08-07', '18:39:10', '2022-08-07 13:09:10', '2022-08-07 13:09:10'),
(6, 1, '::1', 'Dashboard &raquo; Site Menus', 'unknown', 'http://localhost:8181/admin/menus/3/edit/1', '1.38253903', '2022-08-07', '18:39:36', '2022-08-07 13:09:36', '2022-08-07 13:09:36'),
(7, 1, '::1', 'Dashboard &raquo; File Manager', 'unknown', 'http://localhost:8181/admin/file-manager', '1.31456304', '2022-08-07', '18:39:56', '2022-08-07 13:09:56', '2022-08-07 13:09:56'),
(8, 1, '::1', 'Dashboard &raquo; Users &amp; Permissions', 'unknown', 'http://localhost:8181/admin/users', '1.63607979', '2022-08-07', '18:40:05', '2022-08-07 13:10:05', '2022-08-07 13:10:05'),
(9, 1, '::1', 'Dashboard &raquo; Contacts', 'unknown', 'http://localhost:8181/admin/contacts', '1.77877998', '2022-08-07', '18:40:26', '2022-08-07 13:10:26', '2022-08-07 13:10:26'),
(10, 1, '::1', 'Dashboard &raquo; Site Menus', 'unknown', 'http://localhost:8181/admin/menus/1', '0.2732048', '2022-08-07', '18:56:20', '2022-08-07 13:26:20', '2022-08-07 13:26:20'),
(11, 1, '::1', 'Contact Us', 'unknown', 'http://localhost:8181/contact', '0.78566289', '2022-08-07', '19:07:06', '2022-08-07 13:37:06', '2022-08-07 13:37:06'),
(12, 1, '::1', 'Dashboard &raquo; Site pages', 'unknown', 'http://localhost:8181/admin/1/topics', '0.80568004', '2022-08-07', '19:12:43', '2022-08-07 13:42:43', '2022-08-07 13:42:43'),
(13, 1, '::1', 'Dashboard &raquo; Photos', 'unknown', 'http://localhost:8181/admin/4/topics', '0.5802021', '2022-08-07', '19:12:49', '2022-08-07 13:42:49', '2022-08-07 13:42:49'),
(14, 1, '::1', 'Dashboard &raquo; General Settings', 'unknown', 'http://localhost:8181/admin/webmaster', '3.77770996', '2022-08-07', '19:13:05', '2022-08-07 13:43:05', '2022-08-07 13:43:05'),
(15, 1, '::1', 'Dashboard &raquo; Site Sections', 'unknown', 'http://localhost:8181/admin/webmaster/sections', '1.02919102', '2022-08-07', '19:13:23', '2022-08-07 13:43:23', '2022-08-07 13:43:23'),
(16, 1, '::1', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://localhost:8181/admin/banners', '0.874228', '2022-08-07', '19:15:21', '2022-08-07 13:45:21', '2022-08-07 13:45:21'),
(17, 1, '::1', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://localhost:8181/admin/banners/1/edit', '1.08748913', '2022-08-07', '19:16:53', '2022-08-07 13:46:53', '2022-08-07 13:46:53'),
(18, 1, '::1', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://localhost:8181/admin/banners/2/edit', '0.55664802', '2022-08-07', '19:18:32', '2022-08-07 13:48:32', '2022-08-07 13:48:32'),
(19, 1, '::1', 'BAŞ SAHYPA', 'unknown', 'http://localhost:8181/home', '0.27564788', '2022-08-07', '19:24:39', '2022-08-07 13:54:39', '2022-08-07 13:54:39'),
(20, 1, '::1', 'About Us', 'unknown', 'http://localhost:8181/topic/about', '0.51957798', '2022-08-07', '19:38:50', '2022-08-07 14:08:50', '2022-08-07 14:08:50'),
(21, 1, '::1', 'Blog', 'unknown', 'http://localhost:8181/blog', '1.39134622', '2022-08-07', '20:10:49', '2022-08-07 14:40:49', '2022-08-07 14:40:49'),
(22, 1, '::1', 'Privacy', 'unknown', 'http://localhost:8181/topic/privacy', '1.23656416', '2022-08-07', '20:10:52', '2022-08-07 14:40:52', '2022-08-07 14:40:52'),
(23, 1, '::1', 'Home Welcome', 'unknown', 'http://localhost:8181/sitepages/topic/5', '1.36246514', '2022-08-07', '20:12:39', '2022-08-07 14:42:39', '2022-08-07 14:42:39'),
(24, 1, '::1', 'Terms & Conditions', 'unknown', 'http://localhost:8181/topic/terms', '1.2470541', '2022-08-07', '20:15:54', '2022-08-07 14:45:54', '2022-08-07 14:45:54'),
(25, 1, '::1', 'Dashboard &raquo; BAŞ SAHYPA', 'unknown', 'http://localhost:8181/admin/find', '1.29099798', '2022-08-07', '20:22:20', '2022-08-07 14:52:20', '2022-08-07 14:52:20'),
(26, 1, '::1', 'Dashboard &raquo; Services', 'unknown', 'http://localhost:8181/admin/2/topics', '1.25202489', '2022-08-07', '20:26:16', '2022-08-07 14:56:16', '2022-08-07 14:56:16'),
(27, 1, '::1', 'Dashboard &raquo; Products', 'unknown', 'http://localhost:8181/admin/8/topics', '1.18780994', '2022-08-07', '20:28:12', '2022-08-07 14:58:12', '2022-08-07 14:58:12'),
(28, 1, '::1', 'Dashboard &raquo; Categories of  Products', 'unknown', 'http://localhost:8181/admin/8/categories', '1.35857987', '2022-08-07', '20:28:20', '2022-08-07 14:58:20', '2022-08-07 14:58:20'),
(29, 1, '::1', 'Dashboard &raquo; News', 'unknown', 'http://localhost:8181/admin/3/topics', '1.18760204', '2022-08-07', '20:28:28', '2022-08-07 14:58:28', '2022-08-07 14:58:28'),
(30, 1, '::1', 'Dashboard &raquo; Partners', 'unknown', 'http://localhost:8181/admin/9/topics', '1.18952084', '2022-08-07', '20:28:36', '2022-08-07 14:58:36', '2022-08-07 14:58:36'),
(31, 1, '::1', 'Dashboard &raquo; Banners settings', 'unknown', 'http://localhost:8181/admin/webmaster/banners', '1.29717517', '2022-08-07', '20:29:01', '2022-08-07 14:59:01', '2022-08-07 14:59:01'),
(32, 1, '::1', 'Dashboard &raquo; Banners settings', 'unknown', 'http://localhost:8181/admin/webmaster/banners/2/edit', '1.24627805', '2022-08-07', '20:29:06', '2022-08-07 14:59:06', '2022-08-07 14:59:06'),
(33, 1, '::1', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://localhost:8181/admin/banners/3/edit', '1.40833807', '2022-08-07', '20:34:17', '2022-08-07 15:04:17', '2022-08-07 15:04:17'),
(34, 1, '::1', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://localhost:8181/admin/banners/4/edit', '1.20080709', '2022-08-07', '20:38:17', '2022-08-07 15:08:17', '2022-08-07 15:08:17'),
(35, 1, '::1', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://localhost:8181/admin/banners/5/edit', '1.23073292', '2022-08-07', '20:38:29', '2022-08-07 15:08:29', '2022-08-07 15:08:29'),
(36, 1, '::1', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://localhost:8181/admin/banners/6/edit', '1.187186', '2022-08-07', '20:38:41', '2022-08-07 15:08:41', '2022-08-07 15:08:41'),
(37, 1, '::1', 'Dashboard &raquo; Site pages', 'unknown', 'http://localhost:8181/admin/1/topics/create', '1.59675694', '2022-08-07', '20:38:55', '2022-08-07 15:08:55', '2022-08-07 15:08:55'),
(38, 1, '::1', 'Dashboard &raquo; Blog', 'unknown', 'http://localhost:8181/admin/7/topics', '1.245188', '2022-08-07', '20:51:26', '2022-08-07 15:21:26', '2022-08-07 15:21:26'),
(39, 1, '::1', 'Dashboard &raquo; Blog', 'unknown', 'http://localhost:8181/admin/7/topics/create', '1.20437503', '2022-08-07', '20:51:29', '2022-08-07 15:21:29', '2022-08-07 15:21:29'),
(40, 1, '::1', 'Dashboard &raquo; 403', 'unknown', 'http://localhost:8181/admin/403', '1.21053505', '2022-08-07', '21:00:47', '2022-08-07 15:30:47', '2022-08-07 15:30:47'),
(41, 1, '::1', 'Dashboard &raquo; ', 'unknown', 'http://localhost:8181/admin/1/topics/5/edit', '2.83955908', '2022-08-07', '21:12:55', '2022-08-07 15:42:55', '2022-08-07 15:42:55'),
(42, 1, '::1', 'Dashboard &raquo; Site Menus', 'unknown', 'http://localhost:8181/admin/menus/create/1', '1.2875452', '2022-08-07', '21:18:42', '2022-08-07 15:48:42', '2022-08-07 15:48:42'),
(43, 1, '::1', 'Dashboard &raquo; Site Menus', 'unknown', 'http://localhost:8181/admin/menus/20/edit/1', '1.20187306', '2022-08-07', '21:19:00', '2022-08-07 15:49:00', '2022-08-07 15:49:00'),
(44, 1, '::1', 'Dashboard &raquo; Products', 'unknown', 'http://localhost:8181/admin/8/topics/create', '1.18814707', '2022-08-07', '21:19:10', '2022-08-07 15:49:10', '2022-08-07 15:49:10'),
(45, 2, '106.203.145.164', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.04903579', '2022-08-07', '21:55:45', '2022-08-07 20:55:45', '2022-08-07 20:55:45'),
(46, 2, '106.203.145.164', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/home', '0.26107788', '2022-08-07', '21:55:58', '2022-08-07 20:55:58', '2022-08-07 20:55:58'),
(47, 2, '106.203.145.164', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.13705611', '2022-08-07', '21:56:09', '2022-08-07 20:56:09', '2022-08-07 20:56:09'),
(48, 2, '106.203.145.164', 'Dashboard &raquo; BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/admin', '0.30665803', '2022-08-07', '21:56:20', '2022-08-07 20:56:20', '2022-08-07 20:56:20'),
(49, 2, '106.203.145.164', 'Dashboard &raquo; Users &amp; Permissions', 'unknown', 'http://cms.elipbiy01.com/admin/users/1/edit', '0.16877508', '2022-08-07', '21:57:02', '2022-08-07 20:57:02', '2022-08-07 20:57:02'),
(50, 3, '52.114.32.28', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '0.3008821', '2022-08-07', '21:57:26', '2022-08-07 20:57:26', '2022-08-07 20:57:26'),
(51, 3, '52.114.32.28', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.23654294', '2022-08-07', '21:57:30', '2022-08-07 20:57:30', '2022-08-07 20:57:30'),
(52, 4, '93.171.221.111', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '0.37230492', '2022-08-07', '21:58:24', '2022-08-07 20:58:24', '2022-08-07 20:58:24'),
(53, 4, '93.171.221.111', 'О', 'unknown', 'http://cms.elipbiy01.com/ru/topic/about', '0.358253', '2022-08-07', '22:00:39', '2022-08-07 21:00:39', '2022-08-07 21:00:39'),
(54, 4, '93.171.221.111', 'Заголовок сайта', 'unknown', 'http://cms.elipbiy01.com/ru/home', '0.27934599', '2022-08-07', '22:00:54', '2022-08-07 21:00:54', '2022-08-07 21:00:54'),
(55, 4, '93.171.221.111', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.1774888', '2022-08-07', '22:03:57', '2022-08-07 21:03:57', '2022-08-07 21:03:57'),
(56, 4, '93.171.221.111', 'Dashboard &raquo; Заголовок сайта', 'unknown', 'http://cms.elipbiy01.com/admin', '0.22156096', '2022-08-07', '22:04:20', '2022-08-07 21:04:20', '2022-08-07 21:04:20'),
(57, 4, '93.171.221.111', 'Dashboard &raquo; Analytics', 'unknown', 'http://cms.elipbiy01.com/admin/analytics/country', '0.35219502', '2022-08-07', '22:04:48', '2022-08-07 21:04:48', '2022-08-07 21:04:48'),
(58, 4, '93.171.221.111', 'Dashboard &raquo; IP Inquiry', 'unknown', 'http://cms.elipbiy01.com/admin/ip', '0.17684197', '2022-08-07', '22:07:42', '2022-08-07 21:07:42', '2022-08-07 21:07:42'),
(59, 4, '93.171.221.111', 'Dashboard &raquo; Analytics', 'unknown', 'http://cms.elipbiy01.com/admin/analytics/hostname', '0.1574719', '2022-08-07', '22:07:50', '2022-08-07 21:07:50', '2022-08-07 21:07:50'),
(60, 4, '93.171.221.111', 'Dashboard &raquo; Visitors History', 'unknown', 'http://cms.elipbiy01.com/admin/visitors', '0.16033602', '2022-08-07', '22:07:54', '2022-08-07 21:07:54', '2022-08-07 21:07:54'),
(61, 4, '93.171.221.111', 'Dashboard &raquo; Analytics', 'unknown', 'http://cms.elipbiy01.com/admin/analytics/os', '0.29533792', '2022-08-07', '22:08:28', '2022-08-07 21:08:28', '2022-08-07 21:08:28'),
(62, 4, '93.171.221.111', 'Dashboard &raquo; Analytics', 'unknown', 'http://cms.elipbiy01.com/admin/analytics/city', '0.19789791', '2022-08-07', '22:08:34', '2022-08-07 21:08:34', '2022-08-07 21:08:34'),
(63, 4, '93.171.221.111', 'Dashboard &raquo; Inbox', 'unknown', 'http://cms.elipbiy01.com/admin/webmails', '0.25989795', '2022-08-07', '22:08:41', '2022-08-07 21:08:41', '2022-08-07 21:08:41'),
(64, 4, '93.171.221.111', 'Dashboard &raquo; Страницы сайта', 'unknown', 'http://cms.elipbiy01.com/admin/1/topics', '0.18127298', '2022-08-07', '22:08:52', '2022-08-07 21:08:52', '2022-08-07 21:08:52'),
(65, 4, '93.171.221.111', 'Dashboard &raquo; Дом', 'unknown', 'http://cms.elipbiy01.com/admin/1/topics/5/edit', '0.33731389', '2022-08-07', '22:09:07', '2022-08-07 21:09:07', '2022-08-07 21:09:07'),
(66, 4, '93.171.221.111', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://cms.elipbiy01.com/admin/banners', '0.19015598', '2022-08-07', '22:09:30', '2022-08-07 21:09:30', '2022-08-07 21:09:30'),
(67, 4, '93.171.221.111', 'Dashboard &raquo; File Manager', 'unknown', 'http://cms.elipbiy01.com/admin/file-manager', '0.30354881', '2022-08-07', '22:09:44', '2022-08-07 21:09:44', '2022-08-07 21:09:44'),
(68, 4, '93.171.221.111', 'Dashboard &raquo; General Settings', 'unknown', 'http://cms.elipbiy01.com/admin/settings', '0.19005609', '2022-08-07', '22:09:50', '2022-08-07 21:09:50', '2022-08-07 21:09:50'),
(69, 4, '93.171.221.111', 'Dashboard &raquo; Site Menus', 'unknown', 'http://cms.elipbiy01.com/admin/menus', '0.20706296', '2022-08-07', '22:10:02', '2022-08-07 21:10:02', '2022-08-07 21:10:02'),
(70, 4, '93.171.221.111', 'Dashboard &raquo; Users &amp; Permissions', 'unknown', 'http://cms.elipbiy01.com/admin/users', '0.34128118', '2022-08-07', '22:10:30', '2022-08-07 21:10:30', '2022-08-07 21:10:30'),
(71, 4, '93.171.221.111', 'Dashboard &raquo; General Settings', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster', '0.4369719', '2022-08-07', '22:10:45', '2022-08-07 21:10:45', '2022-08-07 21:10:45'),
(72, 4, '93.171.221.111', 'Dashboard &raquo; Categories of  Товары', 'unknown', 'http://cms.elipbiy01.com/admin/8/categories', '0.55573106', '2022-08-07', '22:12:32', '2022-08-07 21:12:32', '2022-08-07 21:12:32'),
(73, 5, '207.46.13.75', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '0.94629502', '2022-08-07', '22:22:43', '2022-08-07 21:22:43', '2022-08-07 21:22:43'),
(74, 6, '217.174.230.94', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.34010601', '2022-08-08', '01:39:05', '2022-08-08 00:39:05', '2022-08-08 00:39:05'),
(75, 7, '95.85.100.137', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.23082685', '2022-08-08', '04:09:09', '2022-08-08 03:09:09', '2022-08-08 03:09:09'),
(76, 7, '95.85.100.137', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/home', '0.22359514', '2022-08-08', '04:09:39', '2022-08-08 03:09:39', '2022-08-08 03:09:39'),
(77, 7, '95.85.100.137', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.1645081', '2022-08-08', '04:10:01', '2022-08-08 03:10:01', '2022-08-08 03:10:01'),
(78, 8, '217.174.233.14', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.13167596', '2022-08-08', '04:25:09', '2022-08-08 03:25:09', '2022-08-08 03:25:09'),
(79, 8, '217.174.233.14', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.14225316', '2022-08-08', '04:29:00', '2022-08-08 03:29:00', '2022-08-08 03:29:00'),
(80, 8, '217.174.233.14', 'Dashboard &raquo; BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/admin', '0.23623514', '2022-08-08', '04:29:15', '2022-08-08 03:29:15', '2022-08-08 03:29:15'),
(81, 8, '217.174.233.14', 'Dashboard &raquo; Analytics', 'unknown', 'http://cms.elipbiy01.com/admin/analytics/country', '0.21478009', '2022-08-08', '04:29:25', '2022-08-08 03:29:25', '2022-08-08 03:29:25'),
(82, 8, '217.174.233.14', 'Dashboard &raquo; 网站页面', 'unknown', 'http://cms.elipbiy01.com/admin/1/topics', '0.31861591', '2022-08-08', '04:29:58', '2022-08-08 03:29:58', '2022-08-08 03:29:58'),
(83, 8, '217.174.233.14', 'Dashboard &raquo; 服务', 'unknown', 'http://cms.elipbiy01.com/admin/2/topics', '0.14451289', '2022-08-08', '04:30:02', '2022-08-08 03:30:02', '2022-08-08 03:30:02'),
(84, 8, '217.174.233.14', 'Dashboard &raquo; Calendar', 'unknown', 'http://cms.elipbiy01.com/admin/calendar', '0.18341994', '2022-08-08', '04:30:04', '2022-08-08 03:30:04', '2022-08-08 03:30:04'),
(85, 8, '217.174.233.14', 'Dashboard &raquo; Inbox', 'unknown', 'http://cms.elipbiy01.com/admin/webmails', '0.16377306', '2022-08-08', '04:30:08', '2022-08-08 03:30:08', '2022-08-08 03:30:08'),
(86, 8, '217.174.233.14', 'Dashboard &raquo; General Settings', 'unknown', 'http://cms.elipbiy01.com/admin/settings', '0.17016888', '2022-08-08', '04:30:22', '2022-08-08 03:30:22', '2022-08-08 03:30:22'),
(87, 8, '217.174.233.14', 'Dashboard &raquo; General Settings', 'unknown', 'http://cms.elipbiy01.com/admin/settings', '0.16828394', '2022-08-08', '04:30:22', '2022-08-08 03:30:22', '2022-08-08 03:30:22'),
(88, 8, '217.174.233.14', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/home', '0.49055886', '2022-08-08', '04:33:50', '2022-08-08 03:33:50', '2022-08-08 03:33:50'),
(89, 8, '217.174.233.14', 'About Us', 'unknown', 'http://cms.elipbiy01.com/topic/about', '0.24859905', '2022-08-08', '04:33:50', '2022-08-08 03:33:50', '2022-08-08 03:33:50'),
(90, 8, '217.174.233.14', 'Blog', 'unknown', 'http://cms.elipbiy01.com/blog', '0.21211219', '2022-08-08', '04:34:05', '2022-08-08 03:34:05', '2022-08-08 03:34:05'),
(91, 8, '217.174.233.14', 'Privacy', 'unknown', 'http://cms.elipbiy01.com/topic/privacy', '0.1738379', '2022-08-08', '04:34:06', '2022-08-08 03:34:06', '2022-08-08 03:34:06'),
(92, 8, '217.174.233.14', 'Terms & Conditions', 'unknown', 'http://cms.elipbiy01.com/topic/terms', '0.1888361', '2022-08-08', '04:34:06', '2022-08-08 03:34:06', '2022-08-08 03:34:06'),
(93, 8, '217.174.233.14', 'Contact Us', 'unknown', 'http://cms.elipbiy01.com/contact', '0.18887997', '2022-08-08', '04:34:07', '2022-08-08 03:34:07', '2022-08-08 03:34:07'),
(94, 8, '217.174.233.14', 'Dashboard &raquo; Site Sections', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/sections', '0.19470096', '2022-08-08', '04:35:44', '2022-08-08 03:35:44', '2022-08-08 03:35:44'),
(95, 8, '217.174.233.14', 'Dashboard &raquo; General Settings', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster', '0.46052694', '2022-08-08', '04:36:08', '2022-08-08 03:36:08', '2022-08-08 03:36:08'),
(96, 8, '217.174.233.14', 'Dashboard &raquo; Новости', 'unknown', 'http://cms.elipbiy01.com/admin/3/topics', '0.24229598', '2022-08-08', '04:36:17', '2022-08-08 03:36:17', '2022-08-08 03:36:17'),
(97, 8, '217.174.233.14', 'Dashboard &raquo; Новости', 'unknown', 'http://cms.elipbiy01.com/admin/3/topics/create', '0.19058299', '2022-08-08', '04:36:21', '2022-08-08 03:36:21', '2022-08-08 03:36:21'),
(98, 8, '217.174.233.14', 'Dashboard &raquo; Услуги', 'unknown', 'http://cms.elipbiy01.com/admin/2/topics/create', '0.15144587', '2022-08-08', '04:40:17', '2022-08-08 03:40:17', '2022-08-08 03:40:17'),
(99, 8, '217.174.233.14', 'Dashboard &raquo; Фото', 'unknown', 'http://cms.elipbiy01.com/admin/4/topics', '0.18395495', '2022-08-08', '04:40:32', '2022-08-08 03:40:32', '2022-08-08 03:40:32'),
(100, 8, '217.174.233.14', 'Dashboard &raquo; Блог', 'unknown', 'http://cms.elipbiy01.com/admin/7/topics', '0.32408118', '2022-08-08', '04:40:39', '2022-08-08 03:40:39', '2022-08-08 03:40:39'),
(101, 8, '217.174.233.14', 'Dashboard &raquo; Партнеры', 'unknown', 'http://cms.elipbiy01.com/admin/9/topics', '0.18910289', '2022-08-08', '04:40:43', '2022-08-08 03:40:43', '2022-08-08 03:40:43'),
(102, 8, '217.174.233.14', 'Dashboard &raquo; Ad. Banners', 'unknown', 'http://cms.elipbiy01.com/admin/banners', '0.18838501', '2022-08-08', '04:40:45', '2022-08-08 03:40:45', '2022-08-08 03:40:45'),
(103, 8, '217.174.233.14', 'Dashboard &raquo; Site Menus', 'unknown', 'http://cms.elipbiy01.com/admin/menus', '0.15830493', '2022-08-08', '04:43:00', '2022-08-08 03:43:00', '2022-08-08 03:43:00'),
(104, 8, '217.174.233.14', 'Dashboard &raquo; Site Menus', 'unknown', 'http://cms.elipbiy01.com/admin/menus/5/edit/1', '0.16317511', '2022-08-08', '04:43:18', '2022-08-08 03:43:18', '2022-08-08 03:43:18'),
(105, 8, '217.174.233.14', 'Dashboard &raquo; Site Menus', 'unknown', 'http://cms.elipbiy01.com/admin/menus/11/edit/1', '0.16058803', '2022-08-08', '04:43:40', '2022-08-08 03:43:40', '2022-08-08 03:43:40'),
(106, 8, '217.174.233.14', 'Dashboard &raquo; File Manager', 'unknown', 'http://cms.elipbiy01.com/admin/file-manager', '0.29467607', '2022-08-08', '04:43:53', '2022-08-08 03:43:53', '2022-08-08 03:43:53'),
(107, 8, '217.174.233.14', 'Dashboard &raquo; Users &amp; Permissions', 'unknown', 'http://cms.elipbiy01.com/admin/users', '0.2203989', '2022-08-08', '04:44:05', '2022-08-08 03:44:05', '2022-08-08 03:44:05'),
(108, 8, '217.174.233.14', 'Dashboard &raquo; Banners settings', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/banners', '0.14957094', '2022-08-08', '04:45:54', '2022-08-08 03:45:54', '2022-08-08 03:45:54'),
(109, 8, '217.174.233.14', 'Dashboard &raquo; Banners settings', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/banners/1/edit', '0.13905191', '2022-08-08', '04:45:58', '2022-08-08 03:45:58', '2022-08-08 03:45:58'),
(110, 8, '217.174.233.14', 'Dashboard &raquo; Site Menus', 'unknown', 'http://cms.elipbiy01.com/admin/menus/create/1', '0.56182909', '2022-08-08', '04:55:40', '2022-08-08 03:55:40', '2022-08-08 03:55:40'),
(111, 8, '217.174.233.14', 'Dashboard &raquo; Voda', 'unknown', 'http://cms.elipbiy01.com/admin/2/topics/6/edit', '0.21795797', '2022-08-08', '04:57:55', '2022-08-08 03:57:55', '2022-08-08 03:57:55'),
(112, 8, '217.174.233.14', 'Water', 'unknown', 'http://cms.elipbiy01.com/services/topic/6', '0.21140003', '2022-08-08', '05:00:50', '2022-08-08 04:00:50', '2022-08-08 04:00:50'),
(113, 8, '217.174.233.14', '接触', 'unknown', 'http://cms.elipbiy01.com/tk/contact', '0.18508291', '2022-08-08', '05:03:29', '2022-08-08 04:03:29', '2022-08-08 04:03:29'),
(114, 8, '217.174.233.14', '关于', 'unknown', 'http://cms.elipbiy01.com/tk/topic/about', '0.18647504', '2022-08-08', '05:03:33', '2022-08-08 04:03:33', '2022-08-08 04:03:33'),
(115, 8, '217.174.233.14', 'Blog', 'unknown', 'http://cms.elipbiy01.com/tk/blog', '0.17383218', '2022-08-08', '05:03:37', '2022-08-08 04:03:37', '2022-08-08 04:03:37'),
(116, 8, '217.174.233.14', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/tk/home', '0.18838906', '2022-08-08', '05:04:12', '2022-08-08 04:04:12', '2022-08-08 04:04:12'),
(117, 8, '217.174.233.14', 'Dashboard &raquo; 404', 'unknown', 'http://cms.elipbiy01.com/assets/dashboard/js/moment/locale/tk.js', '0.64282703', '2022-08-08', '05:11:02', '2022-08-08 04:11:02', '2022-08-08 04:11:02'),
(118, 8, '217.174.233.14', 'Dashboard &raquo; Site Sections', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/sections/1/edit', '0.17007113', '2022-08-08', '05:14:46', '2022-08-08 04:14:46', '2022-08-08 04:14:46'),
(119, 8, '217.174.233.14', 'Dashboard &raquo; Site Sections', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/sections/2/edit', '0.19749212', '2022-08-08', '05:15:04', '2022-08-08 04:15:04', '2022-08-08 04:15:04'),
(120, 8, '217.174.233.14', 'Dashboard &raquo; Site Sections', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/sections/6/edit', '0.36253619', '2022-08-08', '05:15:57', '2022-08-08 04:15:57', '2022-08-08 04:15:57'),
(121, 8, '217.174.233.14', 'Dashboard &raquo; Site Sections', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/sections/create', '0.15137982', '2022-08-08', '05:16:02', '2022-08-08 04:16:02', '2022-08-08 04:16:02'),
(122, 8, '217.174.233.14', 'Dashboard &raquo; Блог', 'unknown', 'http://cms.elipbiy01.com/admin/7/topics/create', '0.53556919', '2022-08-08', '05:26:48', '2022-08-08 04:26:48', '2022-08-08 04:26:48'),
(123, 8, '217.174.233.14', 'Dashboard &raquo; Categories of  Блог', 'unknown', 'http://cms.elipbiy01.com/admin/7/categories', '0.56147599', '2022-08-08', '05:27:43', '2022-08-08 04:27:43', '2022-08-08 04:27:43'),
(124, 8, '217.174.233.14', 'Dashboard &raquo; Categories of  Блог', 'unknown', 'http://cms.elipbiy01.com/admin/7/categories/create', '0.27272582', '2022-08-08', '05:27:46', '2022-08-08 04:27:46', '2022-08-08 04:27:46'),
(125, 8, '217.174.233.14', 'Dashboard &raquo; Вода блогпост', 'unknown', 'http://cms.elipbiy01.com/admin/7/topics/7/edit', '0.22419405', '2022-08-08', '05:29:19', '2022-08-08 04:29:19', '2022-08-08 04:29:19'),
(126, 8, '217.174.233.14', 'Блог', 'unknown', 'http://cms.elipbiy01.com/ru/blog', '0.23786092', '2022-08-08', '05:29:23', '2022-08-08 04:29:23', '2022-08-08 04:29:23'),
(127, 8, '217.174.233.14', 'Вода блогпост', 'unknown', 'http://cms.elipbiy01.com/ru/blog/topic/7', '0.19774795', '2022-08-08', '05:29:33', '2022-08-08 04:29:33', '2022-08-08 04:29:33'),
(128, 9, '95.85.111.238', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.14130402', '2022-08-08', '05:45:44', '2022-08-08 04:45:44', '2022-08-08 04:45:44'),
(129, 10, '185.69.186.152', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.32547379', '2022-08-10', '10:09:42', '2022-08-10 09:09:42', '2022-08-10 09:09:42'),
(130, 11, '95.85.119.230', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '0.91012001', '2022-08-10', '10:23:54', '2022-08-10 09:23:54', '2022-08-10 09:23:54'),
(131, 11, '95.85.119.230', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.16163898', '2022-08-10', '10:24:11', '2022-08-10 09:24:11', '2022-08-10 09:24:11'),
(132, 11, '95.85.119.230', 'Dashboard &raquo; BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/admin', '0.29721594', '2022-08-10', '10:29:26', '2022-08-10 09:29:26', '2022-08-10 09:29:26'),
(133, 11, '95.85.119.230', 'Dashboard &raquo; News', 'unknown', 'http://cms.elipbiy01.com/admin/3/topics', '0.22644615', '2022-08-10', '10:29:48', '2022-08-10 09:29:48', '2022-08-10 09:29:48'),
(134, 11, '95.85.119.230', 'Dashboard &raquo; Photos', 'unknown', 'http://cms.elipbiy01.com/admin/4/topics', '0.15058899', '2022-08-10', '10:29:52', '2022-08-10 09:29:52', '2022-08-10 09:29:52'),
(135, 11, '95.85.119.230', 'Dashboard &raquo; Videos', 'unknown', 'http://cms.elipbiy01.com/admin/5/topics', '0.27706218', '2022-08-10', '10:30:07', '2022-08-10 09:30:07', '2022-08-10 09:30:07'),
(136, 11, '95.85.119.230', 'Dashboard &raquo; Audio', 'unknown', 'http://cms.elipbiy01.com/admin/6/topics', '0.16517496', '2022-08-10', '10:30:14', '2022-08-10 09:30:14', '2022-08-10 09:30:14'),
(137, 11, '95.85.119.230', 'Dashboard &raquo; Users &amp; Permissions', 'unknown', 'http://cms.elipbiy01.com/admin/users', '0.33135819', '2022-08-10', '10:30:32', '2022-08-10 09:30:32', '2022-08-10 09:30:32'),
(138, 11, '95.85.119.230', 'Dashboard &raquo; New Permission', 'unknown', 'http://cms.elipbiy01.com/admin/users/permissions/create', '0.15712619', '2022-08-10', '10:30:36', '2022-08-10 09:30:36', '2022-08-10 09:30:36'),
(139, 11, '95.85.119.230', 'Dashboard &raquo; Site Menus', 'unknown', 'http://cms.elipbiy01.com/admin/menus', '0.1949451', '2022-08-10', '10:31:58', '2022-08-10 09:31:58', '2022-08-10 09:31:58'),
(140, 11, '95.85.119.230', 'Dashboard &raquo; General Settings', 'unknown', 'http://cms.elipbiy01.com/admin/settings', '0.26359415', '2022-08-10', '10:32:05', '2022-08-10 09:32:05', '2022-08-10 09:32:05'),
(141, 11, '95.85.119.230', 'Dashboard &raquo; Site Menus', 'unknown', 'http://cms.elipbiy01.com/admin/menus/9/edit/1', '0.198699', '2022-08-10', '10:34:16', '2022-08-10 09:34:16', '2022-08-10 09:34:16'),
(142, 11, '95.85.119.230', 'Dashboard &raquo; Categories of  Audio', 'unknown', 'http://cms.elipbiy01.com/admin/6/categories', '0.16725898', '2022-08-10', '10:34:43', '2022-08-10 09:34:43', '2022-08-10 09:34:43'),
(143, 11, '95.85.119.230', 'Dashboard &raquo; Categories of  Videos', 'unknown', 'http://cms.elipbiy01.com/admin/5/categories', '0.16692901', '2022-08-10', '10:34:48', '2022-08-10 09:34:48', '2022-08-10 09:34:48'),
(144, 11, '95.85.119.230', 'Dashboard &raquo; Site pages', 'unknown', 'http://cms.elipbiy01.com/admin/1/topics', '0.16019201', '2022-08-10', '10:34:52', '2022-08-10 09:34:52', '2022-08-10 09:34:52'),
(145, 11, '95.85.119.230', 'Dashboard &raquo; Privacy', 'unknown', 'http://cms.elipbiy01.com/admin/1/topics/3/edit', '0.329422', '2022-08-10', '10:35:00', '2022-08-10 09:35:00', '2022-08-10 09:35:00'),
(146, 11, '95.85.119.230', 'Dashboard &raquo; Categories of  Blog', 'unknown', 'http://cms.elipbiy01.com/admin/7/categories', '0.41766405', '2022-08-10', '10:35:33', '2022-08-10 09:35:33', '2022-08-10 09:35:33'),
(147, 11, '95.85.119.230', 'Dashboard &raquo; Blog', 'unknown', 'http://cms.elipbiy01.com/admin/7/topics', '0.13966417', '2022-08-10', '10:35:46', '2022-08-10 09:35:46', '2022-08-10 09:35:46'),
(148, 11, '95.85.119.230', 'Dashboard &raquo; Blog', 'unknown', 'http://cms.elipbiy01.com/admin/7/topics/create', '0.18411708', '2022-08-10', '10:35:50', '2022-08-10 09:35:50', '2022-08-10 09:35:50'),
(149, 11, '95.85.119.230', 'Dashboard &raquo; Test en', 'unknown', 'http://cms.elipbiy01.com/admin/7/topics/8/edit', '0.21599412', '2022-08-10', '10:36:57', '2022-08-10 09:36:57', '2022-08-10 09:36:57'),
(150, 11, '95.85.119.230', 'Test en', 'unknown', 'http://cms.elipbiy01.com/blog/topic/8', '0.22249222', '2022-08-10', '10:37:07', '2022-08-10 09:37:07', '2022-08-10 09:37:07'),
(151, 11, '95.85.119.230', 'Dashboard &raquo; General Settings', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster', '0.48688889', '2022-08-10', '10:39:26', '2022-08-10 09:39:26', '2022-08-10 09:39:26'),
(152, 11, '95.85.119.230', 'Dashboard &raquo; Site Sections', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/sections', '0.17890787', '2022-08-10', '10:39:40', '2022-08-10 09:39:40', '2022-08-10 09:39:40'),
(153, 11, '95.85.119.230', 'Dashboard &raquo; Banners settings', 'unknown', 'http://cms.elipbiy01.com/admin/webmaster/banners', '0.16601801', '2022-08-10', '10:40:23', '2022-08-10 09:40:23', '2022-08-10 09:40:23'),
(154, 11, '95.85.119.230', 'Dashboard &raquo; Analytics', 'unknown', 'http://cms.elipbiy01.com/admin/analytics/date', '0.55481887', '2022-08-10', '10:53:34', '2022-08-10 09:53:34', '2022-08-10 09:53:34'),
(155, 11, '95.85.119.230', 'Contact Us', 'unknown', 'http://cms.elipbiy01.com/contact', '0.62190008', '2022-08-10', '10:56:07', '2022-08-10 09:56:07', '2022-08-10 09:56:07'),
(156, 11, '95.85.119.230', 'Dashboard &raquo; Users &amp; Permissions', 'unknown', 'http://cms.elipbiy01.com/admin/users/1/edit', '0.1752789', '2022-08-10', '11:47:09', '2022-08-10 10:47:09', '2022-08-10 10:47:09'),
(157, 12, '49.36.225.150', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.38379407', '2022-08-13', '16:30:01', '2022-08-13 15:30:01', '2022-08-13 15:30:01'),
(158, 12, '49.36.225.150', 'Water', 'unknown', 'http://cms.elipbiy01.com/services/topic/6', '0.46175098', '2022-08-13', '16:30:37', '2022-08-13 15:30:37', '2022-08-13 15:30:37'),
(159, 13, '39.48.240.52', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.27318692', '2022-08-13', '16:41:11', '2022-08-13 15:41:11', '2022-08-13 15:41:11'),
(160, 14, '175.107.218.243', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '0.99474001', '2022-08-13', '16:45:26', '2022-08-13 15:45:26', '2022-08-13 15:45:26'),
(161, 14, '175.107.218.243', 'test  ru', 'unknown', 'http://cms.elipbiy01.com/ru/blog/topic/8', '0.72501683', '2022-08-13', '16:52:25', '2022-08-13 15:52:25', '2022-08-13 15:52:25'),
(162, 15, '103.252.167.57', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.30196285', '2022-08-13', '17:21:04', '2022-08-13 16:21:04', '2022-08-13 16:21:04'),
(163, 16, '122.173.24.239', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.36679006', '2022-08-13', '17:56:16', '2022-08-13 16:56:16', '2022-08-13 16:56:16'),
(164, 16, '122.173.24.239', 'About Us', 'unknown', 'http://cms.elipbiy01.com/topic/about', '1.28450608', '2022-08-13', '18:08:03', '2022-08-13 17:08:03', '2022-08-13 17:08:03'),
(165, 16, '122.173.24.239', 'Water', 'unknown', 'http://cms.elipbiy01.com/services/topic/6', '0.75062895', '2022-08-13', '18:08:07', '2022-08-13 17:08:07', '2022-08-13 17:08:07'),
(166, 17, '40.77.167.31', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.49688101', '2022-08-13', '21:13:35', '2022-08-13 20:13:35', '2022-08-13 20:13:35'),
(167, 18, '93.171.221.111', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.25282907', '2022-08-14', '20:22:13', '2022-08-14 19:22:13', '2022-08-14 19:22:13'),
(168, 19, '93.171.220.186', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.30275106', '2022-08-15', '16:41:31', '2022-08-15 15:41:31', '2022-08-15 15:41:31'),
(169, 19, '93.171.220.186', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.14564204', '2022-08-15', '16:41:41', '2022-08-15 15:41:41', '2022-08-15 15:41:41'),
(170, 19, '93.171.220.186', 'Dashboard &raquo; BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/admin', '0.24806213', '2022-08-15', '16:41:56', '2022-08-15 15:41:56', '2022-08-15 15:41:56'),
(171, 19, '93.171.220.186', 'Dashboard &raquo; 404', 'unknown', 'http://cms.elipbiy01.com/assets/dashboard/js/moment/locale/tk.js', '0.1368649', '2022-08-15', '16:42:15', '2022-08-15 15:42:15', '2022-08-15 15:42:15'),
(172, 20, '122.173.24.239', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/', '1.21890092', '2022-08-16', '05:16:39', '2022-08-16 04:16:39', '2022-08-16 04:16:39'),
(173, 20, '122.173.24.239', 'BAŞ SAHYPA', 'unknown', 'http://cms.elipbiy01.com/home', '0.8510592', '2022-08-16', '05:25:25', '2022-08-16 04:25:25', '2022-08-16 04:25:25'),
(174, 20, '122.173.24.239', 'Water', 'unknown', 'http://cms.elipbiy01.com/services/topic/6', '0.22894692', '2022-08-16', '05:25:32', '2022-08-16 04:25:32', '2022-08-16 04:25:32'),
(175, 20, '122.173.24.239', 'Blog', 'unknown', 'http://cms.elipbiy01.com/blog', '0.36568284', '2022-08-16', '05:25:43', '2022-08-16 04:25:43', '2022-08-16 04:25:43'),
(176, 20, '122.173.24.239', 'Dashboard &raquo; Sign in to CONTROL', 'unknown', 'http://cms.elipbiy01.com/admin/login', '0.15845609', '2022-08-16', '05:26:00', '2022-08-16 04:26:00', '2022-08-16 04:26:00');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_analytics_visitors`
--

CREATE TABLE `smartend_analytics_visitors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_cor1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_cor2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolution` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hostname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `org` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_analytics_visitors`
--

INSERT INTO `smartend_analytics_visitors` (`id`, `ip`, `city`, `country_code`, `country`, `region`, `full_address`, `location_cor1`, `location_cor2`, `os`, `browser`, `resolution`, `referrer`, `hostname`, `org`, `date`, `time`, `created_at`, `updated_at`) VALUES
(1, '::1', 'unknown', 'US', 'unknown', 'Connecticut', NULL, '41.31', '-72.92', 'Windows 10', 'Chrome', 'unknown', 'http://localhost:8181/install/final', 'NA', 'America/New_York', '2022-08-07', '18:32:48', '2022-08-07 13:02:48', '2022-08-07 13:02:48'),
(2, '106.203.145.164', 'Guwahati', 'IN', 'India', 'Assam', NULL, '26.1206', '91.6523', 'Windows 10', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Kolkata', '2022-08-07', '21:55:45', '2022-08-07 20:55:45', '2022-08-07 20:55:45'),
(3, '52.114.32.28', 'Tokyo', 'JP', 'Japan', 'Tokyo', NULL, '35.68', '139.77', 'Windows 7', NULL, 'unknown', 'unknown', 'Unknown', 'Asia/Tokyo', '2022-08-07', '21:57:26', '2022-08-07 20:57:26', '2022-08-07 20:57:26'),
(4, '93.171.221.111', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.95', '58.3833', 'Windows 8.1', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Ashgabat', '2022-08-07', '21:58:24', '2022-08-07 20:58:24', '2022-08-07 20:58:24'),
(5, '207.46.13.75', 'Quincy', 'US', 'United States', 'Washington', NULL, '47.233', '-119.852', 'Windows 7', NULL, 'unknown', 'unknown', 'Unknown', 'America/Los_Angeles', '2022-08-07', '22:22:43', '2022-08-07 21:22:43', '2022-08-07 21:22:43'),
(6, '217.174.230.94', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.95', '58.3833', 'Windows 8.1', 'Chrome', 'unknown', 'https://cms.elipbiy01.com/ru/home', 'Unknown', 'Asia/Ashgabat', '2022-08-08', '01:39:05', '2022-08-08 00:39:05', '2022-08-08 00:39:05'),
(7, '95.85.100.137', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.95', '58.3833', 'Android', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Ashgabat', '2022-08-08', '04:09:09', '2022-08-08 03:09:09', '2022-08-08 03:09:09'),
(8, '217.174.233.14', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.95', '58.3833', 'Windows 10', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Ashgabat', '2022-08-08', '04:25:09', '2022-08-08 03:25:09', '2022-08-08 03:25:09'),
(9, '95.85.111.238', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.95', '58.3833', 'Windows 10', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Ashgabat', '2022-08-08', '05:45:44', '2022-08-08 04:45:44', '2022-08-08 04:45:44'),
(10, '185.69.186.152', 'unknown', 'US', 'unknown', 'Connecticut', NULL, '41.31', '-72.92', 'Android', 'Chrome', 'unknown', 'unknown', 'NA', 'America/New_York', '2022-08-10', '10:09:42', '2022-08-10 09:09:42', '2022-08-10 09:09:42'),
(11, '95.85.119.230', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.9601', '58.3261', 'Windows 10', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Ashgabat', '2022-08-10', '10:23:54', '2022-08-10 09:23:54', '2022-08-10 09:23:54'),
(12, '49.36.225.150', 'Chandigarh', 'IN', 'India', 'Chandigarh', NULL, '30.7339', '76.7889', 'Windows 10', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Kolkata', '2022-08-13', '16:30:01', '2022-08-13 15:30:01', '2022-08-13 15:30:01'),
(13, '39.48.240.52', 'Karachi', 'PK', 'Pakistan', 'Sindh', NULL, '24.8591', '66.9983', 'Windows 10', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Karachi', '2022-08-13', '16:41:11', '2022-08-13 15:41:11', '2022-08-13 15:41:11'),
(14, '175.107.218.243', 'Karachi', 'PK', 'Pakistan', 'Sindh', NULL, '24.9246', '67.087', 'Windows 7', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Karachi', '2022-08-13', '16:45:26', '2022-08-13 15:45:26', '2022-08-13 15:45:26'),
(15, '103.252.167.57', 'Kolkata', 'IN', 'India', 'West Bengal', NULL, '22.518', '88.3832', 'Windows 10', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Kolkata', '2022-08-13', '17:21:04', '2022-08-13 16:21:04', '2022-08-13 16:21:04'),
(16, '122.173.24.239', 'Chandigarh', 'IN', 'India', 'Chandigarh', NULL, '30.7339', '76.7889', 'Windows 10', 'Firefox', 'unknown', 'unknown', 'Unknown', 'Asia/Kolkata', '2022-08-13', '17:56:16', '2022-08-13 16:56:16', '2022-08-13 16:56:16'),
(17, '40.77.167.31', 'Boydton', 'US', 'United States', 'Virginia', NULL, '36.677696', '-78.37471', 'Windows 7', NULL, 'unknown', 'unknown', 'Unknown', 'America/New_York', '2022-08-13', '21:13:35', '2022-08-13 20:13:35', '2022-08-13 20:13:35'),
(18, '93.171.221.111', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.95', '58.3833', 'Windows 8.1', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Ashgabat', '2022-08-14', '20:22:13', '2022-08-14 19:22:13', '2022-08-14 19:22:13'),
(19, '93.171.220.186', 'Ashgabat', 'TM', 'Turkmenistan', 'Ashgabat', NULL, '37.95', '58.3833', 'Android', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Ashgabat', '2022-08-15', '16:41:31', '2022-08-15 15:41:31', '2022-08-15 15:41:31'),
(20, '122.173.24.239', 'Chandigarh', 'IN', 'India', 'Chandigarh', NULL, '30.7339', '76.7889', 'Linux', 'Chrome', 'unknown', 'unknown', 'Unknown', 'Asia/Kolkata', '2022-08-16', '05:16:39', '2022-08-16 04:16:39', '2022-08-16 04:16:39');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_attach_files`
--

CREATE TABLE `smartend_attach_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` int(11) NOT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row_no` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_banners`
--

CREATE TABLE `smartend_banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `section_id` int(11) NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_en` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tk` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_ru` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_fr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_de` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_type` tinyint(4) DEFAULT NULL,
  `youtube_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `visits` int(11) NOT NULL,
  `row_no` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_banners`
--

INSERT INTO `smartend_banners` (`id`, `section_id`, `title_en`, `title_tr`, `title_tk`, `title_ru`, `title_fr`, `title_de`, `details_en`, `details_tr`, `details_tk`, `details_ru`, `details_fr`, `details_de`, `code`, `file_en`, `file_tr`, `file_tk`, `file_ru`, `file_fr`, `file_de`, `video_type`, `youtube_link`, `link_url`, `icon`, `status`, `visits`, `row_no`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Banner #1', '横幅 #1', 'Bandera #1', 'Баннер #1', 'Bannière #1', 'Banner #1', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', NULL, '16598998631568.png', 'noimg.png', 'noimg.png', '16598998639610.png', 'noimg.png', 'noimg.png', NULL, NULL, '#', NULL, 0, 0, 1, 1, 1, '2022-08-07 13:02:35', '2022-08-07 13:53:24'),
(2, 1, 'Banner #2', '横幅 #2', 'Bandera #2', 'Баннер #2', 'Bannière #2', 'Banner #2', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', NULL, 'noimg.png', 'noimg.png', 'noimg.png', 'noimg.png', 'noimg.png', 'noimg.png', NULL, NULL, '#', NULL, 0, 0, 2, 1, 1, '2022-08-07 13:02:35', '2022-08-07 13:48:38'),
(3, 2, 'Suw tölegi', '响应式设计', 'Diseño de respuesta', 'Адаптивный дизайн', 'onception réactive', 'Reagerend ontwerp', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', NULL, '', '', '', '', '', '', NULL, NULL, '#', 'fa-object-group', 1, 0, 1, 1, 1, '2022-08-07 13:02:35', '2022-08-07 15:05:28'),
(4, 2, 'Suw tölegi', 'HTML5 和 CSS3', 'HTML5 y CSS3', 'HTML5 и CSS3', 'HTML5 et CSS3', 'HTML5 & CSS3', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', NULL, '', '', '', '', '', '', NULL, NULL, '#', 'fa-html5', 1, 0, 2, 1, 1, '2022-08-07 13:02:35', '2022-08-07 15:08:23'),
(5, 2, 'Suw tölegi', '使用的引导程序', 'Bootstrap utilizado', 'Bootstrap', 'Bootstrap utilisé', 'Bootstrap gebruikt', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', NULL, '', '', '', '', '', '', NULL, NULL, '#', 'fa-code', 1, 0, 3, 1, 1, '2022-08-07 13:02:35', '2022-08-07 15:08:35'),
(6, 2, 'Suw tölegi', '经典设计', 'Diseño clásico', 'Классический', 'Conception classique', 'Klassiek ontwerp', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', NULL, '', '', '', '', '', '', NULL, NULL, '#', 'fa-laptop', 1, 0, 4, 1, 1, '2022-08-07 13:02:35', '2022-08-07 15:08:47');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_comments`
--

CREATE TABLE `smartend_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `row_no` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_comments`
--

INSERT INTO `smartend_comments` (`id`, `topic_id`, `name`, `email`, `date`, `comment`, `status`, `row_no`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 7, 'admin', 'admin@elipbiy01.com', '2022-08-08 05:29:55', '65567', 1, 1, NULL, NULL, '2022-08-08 04:29:55', '2022-08-08 04:29:55');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_contacts`
--

CREATE TABLE `smartend_contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_contacts_groups`
--

CREATE TABLE `smartend_contacts_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_contacts_groups`
--

INSERT INTO `smartend_contacts_groups` (`id`, `name`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Newsletter Emails', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_countries`
--

CREATE TABLE `smartend_countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_countries`
--

INSERT INTO `smartend_countries` (`id`, `code`, `title_en`, `title_ru`, `title_fr`, `title_de`, `tel`, `created_at`, `updated_at`) VALUES
(1, 'AL', 'Albania', 'Albania', 'Albania', 'Albania', '355', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(2, 'DZ', 'Algeria', 'Algeria', 'Algeria', 'Algeria', '213', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(3, 'AS', 'American Samoa', 'American Samoa', 'American Samoa', 'American Samoa', '1-684', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(4, 'AD', 'Andorra', 'Andorra', 'Andorra', 'Andorra', '376', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(5, 'AO', 'Angola', 'Angola', 'Angola', 'Angola', '244', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(6, 'AI', 'Anguilla', 'Anguilla', 'Anguilla', 'Anguilla', '1-264', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(7, 'AR', 'Argentina', 'Argentina', 'Argentina', 'Argentina', '54', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(8, 'AM', 'Armenia', 'Armenia', 'Armenia', 'Armenia', '374', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(9, 'AW', 'Aruba', 'Aruba', 'Aruba', 'Aruba', '297', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(10, 'AU', 'Australia', 'Australia', 'Australia', 'Australia', '61', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(11, 'AT', 'Austria', 'Austria', 'Austria', 'Austria', '43', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(12, 'AZ', 'Azerbaijan', 'Azerbaijan', 'Azerbaijan', 'Azerbaijan', '994', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(13, 'BS', 'Bahamas', 'Bahamas', 'Bahamas', 'Bahamas', '1-242', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(14, 'BH', 'Bahrain', 'Bahrain', 'Bahrain', 'Bahrain', '973', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(15, 'BD', 'Bangladesh', 'Bangladesh', 'Bangladesh', 'Bangladesh', '880', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(16, 'BB', 'Barbados', 'Barbados', 'Barbados', 'Barbados', '1-246', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(17, 'BY', 'Belarus', 'Belarus', 'Belarus', 'Belarus', '375', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(18, 'BE', 'Belgium', 'Belgium', 'Belgium', 'Belgium', '32', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(19, 'BZ', 'Belize', 'Belize', 'Belize', 'Belize', '501', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(20, 'BJ', 'Benin', 'Benin', 'Benin', 'Benin', '229', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(21, 'BM', 'Bermuda', 'Bermuda', 'Bermuda', 'Bermuda', '1-441', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(22, 'BT', 'Bhutan', 'Bhutan', 'Bhutan', 'Bhutan', '975', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(23, 'BO', 'Bolivia', 'Bolivia', 'Bolivia', 'Bolivia', '591', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(24, 'BA', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', '387', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(25, 'BW', 'Botswana', 'Botswana', 'Botswana', 'Botswana', '267', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(26, 'BR', 'Brazil', 'Brazil', 'Brazil', 'Brazil', '55', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(27, 'VG', 'British Virgin Islands', 'British Virgin Islands', 'British Virgin Islands', 'British Virgin Islands', '1-284', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(28, 'IO', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'British Indian Ocean Territory', '246', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(29, 'BN', 'Brunei Darussalam', 'Brunei Darussalam', 'Brunei Darussalam', 'Brunei Darussalam', '673', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(30, 'BG', 'Bulgaria', 'Bulgaria', 'Bulgaria', 'Bulgaria', '359', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(31, 'BF', 'Burkina Faso', 'Burkina Faso', 'Burkina Faso', 'Burkina Faso', '226', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(32, 'BI', 'Burundi', 'Burundi', 'Burundi', 'Burundi', '257', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(33, 'KH', 'Cambodia', 'Cambodia', 'Cambodia', 'Cambodia', '855', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(34, 'CM', 'Cameroon', 'Cameroon', 'Cameroon', 'Cameroon', '237', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(35, 'CA', 'Canada', 'Canada', 'Canada', 'Canada', '1', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(36, 'CV', 'Cape Verde', 'Cape Verde', 'Cape Verde', 'Cape Verde', '238', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(37, 'KY', 'Cayman Islands', 'Cayman Islands', 'Cayman Islands', 'Cayman Islands', '1-345', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(38, 'CF', 'Central African Republic', 'Central African Republic', 'Central African Republic', 'Central African Republic', '236', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(39, 'TD', 'Chad', 'Chad', 'Chad', 'Chad', '235', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(40, 'CL', 'Chile', 'Chile', 'Chile', 'Chile', '56', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(41, 'CN', 'China', 'China', 'China', 'China', '86', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(42, 'HK', 'Hong Kong', 'Hong Kong', 'Hong Kong', 'Hong Kong', '852', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(43, 'MO', 'Macao', 'Macao', 'Macao', 'Macao', '853', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(44, 'CX', 'Christmas Island', 'Christmas Island', 'Christmas Island', 'Christmas Island', '61', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(45, 'CC', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', '61', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(46, 'CO', 'Colombia', 'Colombia', 'Colombia', 'Colombia', '57', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(47, 'KM', 'Comoros', 'Comoros', 'Comoros', 'Comoros', '269', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(48, 'CK', 'Cook Islands', 'Cook Islands', 'Cook Islands', 'Cook Islands', '682', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(49, 'CR', 'Costa Rica', 'Costa Rica', 'Costa Rica', 'Costa Rica', '506', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(50, 'HR', 'Croatia', 'Croatia', 'Croatia', 'Croatia', '385', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(51, 'CU', 'Cuba', 'Cuba', 'Cuba', 'Cuba', '53', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(52, 'CY', 'Cyprus', 'Cyprus', 'Cyprus', 'Cyprus', '357', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(53, 'CZ', 'Czech Republic', 'Czech Republic', 'Czech Republic', 'Czech Republic', '420', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(54, 'DK', 'Denmark', 'Denmark', 'Denmark', 'Denmark', '45', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(55, 'DJ', 'Djibouti', 'Djibouti', 'Djibouti', 'Djibouti', '253', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(56, 'DM', 'Dominica', 'Dominica', 'Dominica', 'Dominica', '1-767', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(57, 'DO', 'Dominican Republic', 'Dominican Republic', 'Dominican Republic', 'Dominican Republic', '1-809', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(58, 'EC', 'Ecuador', 'Ecuador', 'Ecuador', 'Ecuador', '593', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(59, 'EG', 'Egypt', 'Egypt', 'Egypt', 'Egypt', '20', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(60, 'SV', 'El Salvador', 'El Salvador', 'El Salvador', 'El Salvador', '503', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(61, 'GQ', 'Equatorial Guinea', 'Equatorial Guinea', 'Equatorial Guinea', 'Equatorial Guinea', '240', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(62, 'ER', 'Eritrea', 'Eritrea', 'Eritrea', 'Eritrea', '291', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(63, 'EE', 'Estonia', 'Estonia', 'Estonia', 'Estonia', '372', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(64, 'ET', 'Ethiopia', 'Ethiopia', 'Ethiopia', 'Ethiopia', '251', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(65, 'FO', 'Faroe Islands', 'Faroe Islands', 'Faroe Islands', 'Faroe Islands', '298', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(66, 'FJ', 'Fiji', 'Fiji', 'Fiji', 'Fiji', '679', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(67, 'FI', 'Finland', 'Finland', 'Finland', 'Finland', '358', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(68, 'FR', 'France', 'France', 'France', 'France', '33', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(69, 'GF', 'French Guiana', 'French Guiana', 'French Guiana', 'French Guiana', '689', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(70, 'GA', 'Gabon', 'Gabon', 'Gabon', 'Gabon', '241', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(71, 'GM', 'Gambia', 'Gambia', 'Gambia', 'Gambia', '220', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(72, 'GE', 'Georgia', 'Georgia', 'Georgia', 'Georgia', '995', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(73, 'DE', 'Germany', 'Germany', 'Germany', 'Germany', '49', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(74, 'GH', 'Ghana', 'Ghana', 'Ghana', 'Ghana', '233', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(75, 'GI', 'Gibraltar', 'Gibraltar', 'Gibraltar', 'Gibraltar', '350', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(76, 'GR', 'Greece', 'Greece', 'Greece', 'Greece', '30', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(77, 'GL', 'Greenland', 'Greenland', 'Greenland', 'Greenland', '299', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(78, 'GD', 'Grenada', 'Grenada', 'Grenada', 'Grenada', '1-473', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(79, 'GU', 'Guam', 'Guam', 'Guam', 'Guam', '1-671', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(80, 'GT', 'Guatemala', 'Guatemala', 'Guatemala', 'Guatemala', '502', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(81, 'GN', 'Guinea', 'Guinea', 'Guinea', 'Guinea', '224', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(82, 'GW', 'Guinea-Bissau', 'Guinea-Bissau', 'Guinea-Bissau', 'Guinea-Bissau', '245', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(83, 'GY', 'Guyana', 'Guyana', 'Guyana', 'Guyana', '592', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(84, 'HT', 'Haiti', 'Haiti', 'Haiti', 'Haiti', '509', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(85, 'HN', 'Honduras', 'Honduras', 'Honduras', 'Honduras', '504', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(86, 'HU', 'Hungary', 'Hungary', 'Hungary', 'Hungary', '36', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(87, 'IS', 'Iceland', 'Iceland', 'Iceland', 'Iceland', '354', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(88, 'IN', 'India', 'India', 'India', 'India', '91', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(89, 'ID', 'Indonesia', 'Indonesia', 'Indonesia', 'Indonesia', '62', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(90, 'IR', 'Iran, Islamic Republic of', 'Iran, Islamic Republic of', 'Iran, Islamic Republic of', 'Iran, Islamic Republic of', '98', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(91, 'IQ', 'Iraq', 'Iraq', 'Iraq', 'Iraq', '964', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(92, 'IE', 'Ireland', 'Ireland', 'Ireland', 'Ireland', '353', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(93, 'IM', 'Isle of Man', 'Isle of Man', 'Isle of Man', 'Isle of Man', '44-1624', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(94, 'IL', 'Israel', 'Israel', 'Israel', 'Israel', '972', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(95, 'IT', 'Italy', 'Italy', 'Italy', 'Italy', '39', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(96, 'JM', 'Jamaica', 'Jamaica', 'Jamaica', 'Jamaica', '1-876', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(97, 'JP', 'Japan', 'Japan', 'Japan', 'Japan', '81', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(98, 'JE', 'Jersey', 'Jersey', 'Jersey', 'Jersey', '44-1534', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(99, 'JO', 'Jordan', 'Jordan', 'Jordan', 'Jordan', '962', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(100, 'KZ', 'Kazakhstan', 'Kazakhstan', 'Kazakhstan', 'Kazakhstan', '7', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(101, 'KE', 'Kenya', 'Kenya', 'Kenya', 'Kenya', '254', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(102, 'KI', 'Kiribati', 'Kiribati', 'Kiribati', 'Kiribati', '686', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(103, 'KW', 'Kuwait', 'Kuwait', 'Kuwait', 'Kuwait', '965', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(104, 'KG', 'Kyrgyzstan', 'Kyrgyzstan', 'Kyrgyzstan', 'Kyrgyzstan', '996', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(105, 'LV', 'Latvia', 'Latvia', 'Latvia', 'Latvia', '371', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(106, 'LB', 'Lebanon', 'Lebanon', 'Lebanon', 'Lebanon', '961', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(107, 'LS', 'Lesotho', 'Lesotho', 'Lesotho', 'Lesotho', '266', '2022-08-07 13:02:33', '2022-08-07 13:02:34'),
(108, 'LR', 'Liberia', 'Liberia', 'Liberia', 'Liberia', '231', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(109, 'LY', 'Libya', 'Libya', 'Libya', 'Libya', '218', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(110, 'LI', 'Liechtenstein', 'Liechtenstein', 'Liechtenstein', 'Liechtenstein', '423', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(111, 'LT', 'Lithuania', 'Lithuania', 'Lithuania', 'Lithuania', '370', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(112, 'LU', 'Luxembourg', 'Luxembourg', 'Luxembourg', 'Luxembourg', '352', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(113, 'MK', 'Macedonia', 'Macedonia', 'Macedonia', 'Macedonia', '389', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(114, 'MG', 'Madagascar', 'Madagascar', 'Madagascar', 'Madagascar', '261', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(115, 'MW', 'Malawi', 'Malawi', 'Malawi', 'Malawi', '265', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(116, 'MY', 'Malaysia', 'Malaysia', 'Malaysia', 'Malaysia', '60', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(117, 'MV', 'Maldives', 'Maldives', 'Maldives', 'Maldives', '960', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(118, 'ML', 'Mali', 'Mali', 'Mali', 'Mali', '223', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(119, 'MT', 'Malta', 'Malta', 'Malta', 'Malta', '356', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(120, 'MH', 'Marshall Islands', 'Marshall Islands', 'Marshall Islands', 'Marshall Islands', '692', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(121, 'MR', 'Mauritania', 'Mauritania', 'Mauritania', 'Mauritania', '222', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(122, 'MU', 'Mauritius', 'Mauritius', 'Mauritius', 'Mauritius', '230', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(123, 'YT', 'Mayotte', 'Mayotte', 'Mayotte', 'Mayotte', '262', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(124, 'MX', 'Mexico', 'Mexico', 'Mexico', 'Mexico', '52', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(125, 'FM', 'Micronesia', 'Micronesia', 'Micronesia', 'Micronesia', '691', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(126, 'MD', 'Moldova', 'Moldova', 'Moldova', 'Moldova', '373', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(127, 'MC', 'Monaco', 'Monaco', 'Monaco', 'Monaco', '377', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(128, 'MN', 'Mongolia', 'Mongolia', 'Mongolia', 'Mongolia', '976', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(129, 'ME', 'Montenegro', 'Montenegro', 'Montenegro', 'Montenegro', '382', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(130, 'MS', 'Montserrat', 'Montserrat', 'Montserrat', 'Montserrat', '1-664', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(131, 'MA', 'Morocco', 'Morocco', 'Morocco', 'Morocco', '212', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(132, 'MZ', 'Mozambique', 'Mozambique', 'Mozambique', 'Mozambique', '258', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(133, 'MM', 'Myanmar', 'Myanmar', 'Myanmar', 'Myanmar', '95', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(134, 'NA', 'Namibia', 'Namibia', 'Namibia', 'Namibia', '264', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(135, 'NR', 'Nauru', 'Nauru', 'Nauru', 'Nauru', '674', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(136, 'NP', 'Nepal', 'Nepal', 'Nepal', 'Nepal', '977', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(137, 'NL', 'Netherlands', 'Netherlands', 'Netherlands', 'Netherlands', '31', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(138, 'AN', 'Netherlands Antilles', 'Netherlands Antilles', 'Netherlands Antilles', 'Netherlands Antilles', '599', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(139, 'NC', 'New Caledonia', 'New Caledonia', 'New Caledonia', 'New Caledonia', '687', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(140, 'NZ', 'New Zealand', 'New Zealand', 'New Zealand', 'New Zealand', '64', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(141, 'NI', 'Nicaragua', 'Nicaragua', 'Nicaragua', 'Nicaragua', '505', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(142, 'NE', 'Niger', 'Niger', 'Niger', 'Niger', '227', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(143, 'NG', 'Nigeria', 'Nigeria', 'Nigeria', 'Nigeria', '234', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(144, 'NU', 'Niue', 'Niue', 'Niue', 'Niue', '683', '2022-08-07 13:02:34', '2022-08-07 13:02:34'),
(145, 'NO', 'Norway', 'Norway', 'Norway', 'Norway', '47', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(146, 'OM', 'Oman', 'Oman', 'Oman', 'Oman', '968', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(147, 'PK', 'Pakistan', 'Pakistan', 'Pakistan', 'Pakistan', '92', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(148, 'PW', 'Palau', 'Palau', 'Palau', 'Palau', '680', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(149, 'PS', 'Palestinian', 'Palestinian', 'Palestinian', 'Palestinian', '972', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(150, 'PA', 'Panama', 'Panama', 'Panama', 'Panama', '507', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(151, 'PY', 'Paraguay', 'Paraguay', 'Paraguay', 'Paraguay', '595', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(152, 'PE', 'Peru', 'Peru', 'Peru', 'Peru', '51', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(153, 'PH', 'Philippines', 'Philippines', 'Philippines', 'Philippines', '63', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(154, 'PN', 'Pitcairn', 'Pitcairn', 'Pitcairn', 'Pitcairn', '870', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(155, 'PL', 'Poland', 'Poland', 'Poland', 'Poland', '48', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(156, 'PT', 'Portugal', 'Portugal', 'Portugal', 'Portugal', '351', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(157, 'PR', 'Puerto Rico', 'Puerto Rico', 'Puerto Rico', 'Puerto Rico', '1-787', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(158, 'QA', 'Qatar', 'Qatar', 'Qatar', 'Qatar', '974', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(159, 'RO', 'Romania', 'Romania', 'Romania', 'Romania', '40', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(160, 'RU', 'Russian Federation', 'Russian Federation', 'Russian Federation', 'Russian Federation', '7', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(161, 'RW', 'Rwanda', 'Rwanda', 'Rwanda', 'Rwanda', '250', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(162, 'SH', 'Saint Helena', 'Saint Helena', 'Saint Helena', 'Saint Helena', '290', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(163, 'KN', 'Saint Kitts and Nevis', 'Saint Kitts and Nevis', 'Saint Kitts and Nevis', 'Saint Kitts and Nevis', '1-869', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(164, 'LC', 'Saint Lucia', 'Saint Lucia', 'Saint Lucia', 'Saint Lucia', '1-758', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(165, 'PM', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', '508', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(166, 'VC', 'Saint Vincent and Grenadines', 'Saint Vincent and Grenadines', 'Saint Vincent and Grenadines', 'Saint Vincent and Grenadines', '1-784', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(167, 'WS', 'Samoa', 'Samoa', 'Samoa', 'Samoa', '685', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(168, 'SM', 'San Marino', 'San Marino', 'San Marino', 'San Marino', '378', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(169, 'ST', 'Sao Tome and Principe', 'Sao Tome and Principe', 'Sao Tome and Principe', 'Sao Tome and Principe', '239', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(170, 'SA', 'Saudi Arabia', 'Saudi Arabia', 'Saudi Arabia', 'Saudi Arabia', '966', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(171, 'SN', 'Senegal', 'Senegal', 'Senegal', 'Senegal', '221', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(172, 'RS', 'Serbia', 'Serbia', 'Serbia', 'Serbia', '381', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(173, 'SC', 'Seychelles', 'Seychelles', 'Seychelles', 'Seychelles', '248', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(174, 'SL', 'Sierra Leone', 'Sierra Leone', 'Sierra Leone', 'Sierra Leone', '232', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(175, 'SG', 'Singapore', 'Singapore', 'Singapore', 'Singapore', '65', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(176, 'SK', 'Slovakia', 'Slovakia', 'Slovakia', 'Slovakia', '421', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(177, 'SI', 'Slovenia', 'Slovenia', 'Slovenia', 'Slovenia', '386', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(178, 'SB', 'Solomon Islands', 'Solomon Islands', 'Solomon Islands', 'Solomon Islands', '677', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(179, 'SO', 'Somalia', 'Somalia', 'Somalia', 'Somalia', '252', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(180, 'ZA', 'South Africa', 'South Africa', 'South Africa', 'South Africa', '27', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(181, 'ES', 'Spain', 'Spain', 'Spain', 'Spain', '34', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(182, 'LK', 'Sri Lanka', 'Sri Lanka', 'Sri Lanka', 'Sri Lanka', '94', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(183, 'SD', 'Sudan', 'Sudan', 'Sudan', 'Sudan', '249', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(184, 'SR', 'Suriname', 'Suriname', 'Suriname', 'Suriname', '597', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(185, 'SJ', 'Svalbard and Jan Mayen Islands', 'Svalbard and Jan Mayen Islands', 'Svalbard and Jan Mayen Islands', 'Svalbard and Jan Mayen Islands', '47', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(186, 'SZ', 'Swaziland', 'Swaziland', 'Swaziland', 'Swaziland', '268', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(187, 'SE', 'Sweden', 'Sweden', 'Sweden', 'Sweden', '46', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(188, 'CH', 'Switzerland', 'Switzerland', 'Switzerland', 'Switzerland', '41', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(189, 'SY', 'Syrian Arab Republic', 'Syrian Arab Republic', 'Syrian Arab Republic', 'Syrian Arab Republic', '963', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(190, 'TW', 'Taiwan, Republic of China', 'Taiwan, Republic of China', 'Taiwan, Republic of China', 'Taiwan, Republic of China', '886', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(191, 'TJ', 'Tajikistan', 'Tajikistan', 'Tajikistan', 'Tajikistan', '992', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(192, 'TZ', 'Tanzania', 'Tanzania', 'Tanzania', 'Tanzania', '255', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(193, 'TH', 'Thailand', 'Thailand', 'Thailand', 'Thailand', '66', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(194, 'TG', 'Togo', 'Togo', 'Togo', 'Togo', '228', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(195, 'TK', 'Tokelau', 'Tokelau', 'Tokelau', 'Tokelau', '690', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(196, 'TO', 'Tonga', 'Tonga', 'Tonga', 'Tonga', '676', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(197, 'TT', 'Trinidad and Tobago', 'Trinidad and Tobago', 'Trinidad and Tobago', 'Trinidad and Tobago', '1-868', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(198, 'TN', 'Tunisia', 'Tunisia', 'Tunisia', 'Tunisia', '216', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(199, 'TR', 'Turkey', 'Turkey', 'Turkey', 'Turkey', '90', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(200, 'TM', 'Turkmenistan', 'Turkmenistan', 'Turkmenistan', 'Turkmenistan', '993', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(201, 'TC', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'Turks and Caicos Islands', '1-649', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(202, 'TV', 'Tuvalu', 'Tuvalu', 'Tuvalu', 'Tuvalu', '688', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(203, 'UG', 'Uganda', 'Uganda', 'Uganda', 'Uganda', '256', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(204, 'UA', 'Ukraine', 'Ukraine', 'Ukraine', 'Ukraine', '380', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(205, 'AE', 'United Arab Emirates', 'United Arab Emirates', 'United Arab Emirates', 'United Arab Emirates', '971', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(206, 'GB', 'United Kingdom', 'United Kingdom', 'United Kingdom', 'United Kingdom', '44', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(207, 'US', 'United States of America', 'United States of America', 'United States of America', 'United States of America', '1', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(208, 'UY', 'Uruguay', 'Uruguay', 'Uruguay', 'Uruguay', '598', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(209, 'UZ', 'Uzbekistan', 'Uzbekistan', 'Uzbekistan', 'Uzbekistan', '998', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(210, 'VU', 'Vanuatu', 'Vanuatu', 'Vanuatu', 'Vanuatu', '678', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(211, 'VE', 'Venezuela', 'Venezuela', 'Venezuela', 'Venezuela', '58', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(212, 'VN', 'Viet Nam', 'Viet Nam', 'Viet Nam', 'Viet Nam', '84', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(213, 'WF', 'Wallis and Futuna Islands', 'Wallis and Futuna Islands', 'Wallis and Futuna Islands', 'Wallis and Futuna Islands', '681', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(214, 'YE', 'Yemen', 'Yemen', 'Yemen', 'Yemen', '967', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(215, 'ZM', 'Zambia', 'Zambia', 'Zambia', 'Zambia', '260', '2022-08-07 13:02:34', '2022-08-07 13:02:35'),
(216, 'ZW', 'Zimbabwe', 'Zimbabwe', 'Zimbabwe', 'Zimbabwe', '263', '2022-08-07 13:02:34', '2022-08-07 13:02:35');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_events`
--

CREATE TABLE `smartend_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 0,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_failed_jobs`
--

CREATE TABLE `smartend_failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_languages`
--

CREATE TABLE `smartend_languages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `left` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `right` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `box_status` tinyint(4) DEFAULT 1,
  `status` tinyint(4) DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_languages`
--

INSERT INTO `smartend_languages` (`id`, `title`, `code`, `direction`, `left`, `right`, `icon`, `box_status`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'English', 'en', 'ltr', 'left', 'right', 'us', 1, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(6, 'русский', 'ru', 'ltr', 'right', 'left', 'ru', 1, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(8, 'Le français', 'fr', 'ltr', 'right', 'left', 'fr', 0, 0, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(9, 'Deutsch', 'de', 'ltr', 'right', 'left', 'de', 0, 0, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(11, 'Turkish', 'tr', 'ltr', 'left', 'right', 'tr', 1, 0, 1, 1, '2022-08-07 13:02:33', '2022-08-08 03:45:25'),
(12, 'Türkmen', 'tk', 'ltr', 'left', 'right', 'tm', 1, 1, 1, 1, '2022-08-07 13:02:33', '2022-08-07 21:18:45');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_maps`
--

CREATE TABLE `smartend_maps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` int(11) NOT NULL,
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_en` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tk` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_ru` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_fr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_de` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `row_no` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_menus`
--

CREATE TABLE `smartend_menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `row_no` int(11) NOT NULL,
  `father_id` int(11) NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_menus`
--

INSERT INTO `smartend_menus` (`id`, `row_no`, `father_id`, `title_en`, `title_tr`, `title_tk`, `title_ru`, `title_fr`, `title_de`, `status`, `type`, `cat_id`, `link`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 'Main Menu', '主菜单', 'Menú principal', 'Главное меню', 'Menu principal', 'Hauptmenü', 1, 0, 0, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(2, 2, 0, 'Quick Links', '快速链接', 'enlaces rápidos', 'Быстрые ссылки', 'Liens rapides', 'Quicklinks', 1, 0, 0, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(3, 1, 1, 'Home', 'Home', 'Home', 'Дом', 'Domicile', 'Home', 1, 1, 1, 'home', 1, 1, '2022-08-07 13:02:35', '2022-08-07 15:48:01'),
(4, 2, 1, 'About', '关于', 'Acerca de', 'О', 'À propos', 'Über uns', 1, 1, 0, 'topic/about', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(5, 3, 1, 'Services', '服务', 'Servicios', 'Услуги', 'services', 'Services', 1, 3, 2, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(6, 4, 1, 'News', '新闻', 'Noticias', 'Новости', 'Nouvelles', 'News', 0, 2, 3, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:26:20'),
(7, 5, 1, 'Photos', '照片', 'Fotos', 'Фото', 'Photos', 'Fotos', 0, 2, 4, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:26:20'),
(8, 6, 1, 'Videos', '视频', 'Videos', 'Видео', 'Vidéos', 'Videos', 0, 3, 5, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:26:20'),
(9, 7, 1, 'Audio', '声音的', 'Audio', 'Аудио', 'l\'audio', 'Audio', 1, 3, 6, NULL, 1, 1, '2022-08-07 13:02:35', '2022-08-10 09:34:20'),
(10, 8, 1, 'Products', '产品', 'Productos', 'Товары', 'Produits', 'Produkte', 1, 3, 8, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(11, 9, 1, 'Blog', '博客', 'Blog', 'Блог', 'Blog', 'Blog', 1, 2, 7, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(12, 10, 1, 'Contact', '接触', 'Contacto', 'Контакт', 'Contact', 'Kontakt', 1, 1, 0, 'contact', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(13, 1, 2, 'Home', '家', 'Casa', 'Дом', 'Domicile', 'Homer', 1, 1, 0, 'home', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(14, 2, 2, 'About', '关于', 'Acerca de', 'О', 'À propos', 'Über uns', 1, 1, 0, 'topic/about', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(15, 3, 2, 'Blog', '博客', 'Blog', 'Блог', 'Blog', 'Blog', 1, 2, 7, '', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(16, 4, 2, 'Privacy', '隐私', 'Intimidad', 'Конфиденциальность', 'Intimité', 'Datenschutz', 1, 1, 0, 'topic/privacy', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(17, 5, 2, 'Terms & Conditions', '条款和条件', 'Términos y condiciones', 'Условия и положения', 'termes et conditions', 'AGB', 1, 1, 0, 'topic/terms', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(18, 6, 2, 'Contact', '接触', 'Contacto', 'Контакт', 'Contact', 'Kontakt', 1, 1, 0, 'contact', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(19, 3, 0, 'test', 'test', 'test', 'test', NULL, NULL, 1, 0, NULL, NULL, 1, NULL, '2022-08-07 15:48:29', '2022-08-07 15:48:29'),
(20, 11, 1, 'test', 'test', 'test', 'test', NULL, NULL, 1, 0, 1, NULL, 1, NULL, '2022-08-07 15:48:59', '2022-08-07 15:48:59');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_migrations`
--

CREATE TABLE `smartend_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_migrations`
--

INSERT INTO `smartend_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2020_09_11_160850_create_sessions_table', 1),
(6, '2020_09_11_190632_create_webmaster_settings_table', 1),
(7, '2020_09_11_190633_create_webmaster_sections_table', 1),
(8, '2020_09_11_190635_create_webmaster_banners_table', 1),
(9, '2020_09_11_190637_create_webmails_groups_table', 1),
(10, '2020_09_11_190638_create_webmails_files_table', 1),
(11, '2020_09_11_190640_create_webmails_table', 1),
(12, '2020_09_11_190641_create_topics_table', 1),
(13, '2020_09_11_190643_create_settings_table', 1),
(14, '2020_09_11_190645_create_sections_table', 1),
(15, '2020_09_11_190647_create_photos_table', 1),
(16, '2020_09_11_190648_create_permissions_table', 1),
(17, '2020_09_11_190650_create_menus_table', 1),
(18, '2020_09_11_190652_create_maps_table', 1),
(19, '2020_09_11_190654_create_events_table', 1),
(20, '2020_09_11_190656_create_countries_table', 1),
(21, '2020_09_11_190657_create_contacts_groups_table', 1),
(22, '2020_09_11_190659_create_contacts_table', 1),
(23, '2020_09_11_190701_create_comments_table', 1),
(24, '2020_09_11_190703_create_banners_table', 1),
(25, '2020_09_11_190704_create_attach_files_table', 1),
(26, '2020_09_11_190706_create_analytics_visitors_table', 1),
(27, '2020_09_11_190708_create_analytics_pages_table', 1),
(28, '2020_09_11_190912_create_related_topics_table', 1),
(29, '2020_09_11_190914_create_topic_categories_table', 1),
(30, '2020_09_11_190916_create_topic_fields_table', 1),
(31, '2020_09_11_190917_create_webmaster_section_fields_table', 1),
(32, '2020_09_11_201046_create_languages_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `smartend_password_resets`
--

CREATE TABLE `smartend_password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_permissions`
--

CREATE TABLE `smartend_permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_status` tinyint(4) NOT NULL DEFAULT 0,
  `add_status` tinyint(4) NOT NULL DEFAULT 0,
  `edit_status` tinyint(4) NOT NULL DEFAULT 0,
  `delete_status` tinyint(4) NOT NULL DEFAULT 0,
  `active_status` tinyint(4) NOT NULL DEFAULT 0,
  `analytics_status` tinyint(4) NOT NULL DEFAULT 0,
  `inbox_status` tinyint(4) NOT NULL DEFAULT 0,
  `newsletter_status` tinyint(4) NOT NULL DEFAULT 0,
  `calendar_status` tinyint(4) NOT NULL DEFAULT 0,
  `banners_status` tinyint(4) NOT NULL DEFAULT 0,
  `settings_status` tinyint(4) NOT NULL DEFAULT 0,
  `webmaster_status` tinyint(4) NOT NULL DEFAULT 0,
  `data_sections` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_status` tinyint(4) NOT NULL DEFAULT 0,
  `home_links` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_ar` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_en` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_ch` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_hi` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_es` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_ru` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_pt` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_fr` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_de` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_details_th` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_permissions`
--

INSERT INTO `smartend_permissions` (`id`, `name`, `view_status`, `add_status`, `edit_status`, `delete_status`, `active_status`, `analytics_status`, `inbox_status`, `newsletter_status`, `calendar_status`, `banners_status`, `settings_status`, `webmaster_status`, `data_sections`, `home_status`, `home_links`, `home_details_ar`, `home_details_en`, `home_details_ch`, `home_details_hi`, `home_details_es`, `home_details_ru`, `home_details_pt`, `home_details_fr`, `home_details_de`, `home_details_th`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Webmaster', 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '1,2,3,4,5,6,7,8,9', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(2, 'Website Manager', 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, '1,2,3,4,5,6,7,8,9', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(3, 'Limited User', 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, '1,2,3,4,5,6,7,8,9', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_photos`
--

CREATE TABLE `smartend_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` int(11) NOT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row_no` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_related_topics`
--

CREATE TABLE `smartend_related_topics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` int(11) NOT NULL,
  `topic2_id` int(11) NOT NULL,
  `row_no` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_sections`
--

CREATE TABLE `smartend_sections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `visits` int(11) NOT NULL,
  `webmaster_id` int(11) NOT NULL,
  `father_id` int(11) NOT NULL,
  `row_no` int(11) NOT NULL,
  `seo_title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_sections`
--

INSERT INTO `smartend_sections` (`id`, `title_en`, `title_tr`, `title_tk`, `title_ru`, `title_fr`, `title_de`, `photo`, `icon`, `status`, `visits`, `webmaster_id`, `father_id`, `row_no`, `seo_title_en`, `seo_title_tr`, `seo_title_tk`, `seo_title_ru`, `seo_title_fr`, `seo_title_de`, `seo_description_en`, `seo_description_tr`, `seo_description_tk`, `seo_description_ru`, `seo_description_fr`, `seo_description_de`, `seo_keywords_en`, `seo_keywords_tr`, `seo_keywords_tk`, `seo_keywords_ru`, `seo_keywords_fr`, `seo_keywords_de`, `seo_url_slug_en`, `seo_url_slug_tr`, `seo_url_slug_tk`, `seo_url_slug_ru`, `seo_url_slug_fr`, `seo_url_slug_de`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Water news', NULL, 'Agyzsuw täzelikleri', 'Voda novosti', NULL, NULL, NULL, NULL, 1, 0, 7, 0, 1, 'Water news', NULL, 'Agyzsuw täzelikleri', 'Voda novosti', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'water-news', NULL, 'agyzsuw-tazelikleri', 'voda-novosti', NULL, NULL, 1, NULL, '2022-08-08 04:28:11', '2022-08-08 04:28:11');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_sessions`
--

CREATE TABLE `smartend_sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_settings`
--

CREATE TABLE `smartend_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_desc_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_desc_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_desc_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_desc_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_desc_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_en` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_ch` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_es` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_ru` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_fr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_de` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_webmails` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_messages_status` tinyint(4) DEFAULT NULL,
  `notify_comments_status` tinyint(4) DEFAULT NULL,
  `notify_orders_status` tinyint(4) DEFAULT NULL,
  `notify_table_status` tinyint(4) DEFAULT NULL,
  `notify_private_status` tinyint(4) DEFAULT NULL,
  `site_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_status` tinyint(4) NOT NULL,
  `close_msg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link7` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link8` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link9` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_link10` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_ch` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_es` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t1_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_ch` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_es` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_t7_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_ch` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_es` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_logo_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_fav` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_apple` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_color1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_color2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_type` tinyint(4) DEFAULT NULL,
  `style_bg_type` tinyint(4) DEFAULT NULL,
  `style_bg_pattern` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_bg_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_bg_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_subscribe` tinyint(4) DEFAULT NULL,
  `style_footer` tinyint(4) DEFAULT NULL,
  `style_header` tinyint(4) DEFAULT NULL,
  `style_footer_bg` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style_preload` tinyint(4) DEFAULT NULL,
  `css` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_settings`
--

INSERT INTO `smartend_settings` (`id`, `site_title_tk`, `site_title_tr`, `site_title_en`, `site_title_ru`, `site_title_de`, `site_desc_en`, `site_desc_ru`, `site_desc_de`, `site_desc_tk`, `site_desc_tr`, `site_keywords_en`, `site_keywords_ch`, `site_keywords_es`, `site_keywords_ru`, `site_keywords_fr`, `site_keywords_de`, `site_keywords_tr`, `site_keywords_tk`, `site_webmails`, `notify_messages_status`, `notify_comments_status`, `notify_orders_status`, `notify_table_status`, `notify_private_status`, `site_url`, `site_status`, `close_msg`, `social_link1`, `social_link2`, `social_link3`, `social_link4`, `social_link5`, `social_link6`, `social_link7`, `social_link8`, `social_link9`, `social_link10`, `contact_t1_en`, `contact_t1_ch`, `contact_t1_es`, `contact_t1_ru`, `contact_t1_fr`, `contact_t1_de`, `contact_t1_tk`, `contact_t1_tr`, `contact_t3`, `contact_t4`, `contact_t5`, `contact_t6`, `contact_t7_en`, `contact_t7_ch`, `contact_t7_es`, `contact_t7_ru`, `contact_t7_fr`, `contact_t7_de`, `contact_t7_tr`, `contact_t7_tk`, `style_logo_en`, `style_logo_ch`, `style_logo_es`, `style_logo_ru`, `style_logo_fr`, `style_logo_de`, `style_logo_tk`, `style_logo_tr`, `style_fav`, `style_apple`, `style_color1`, `style_color2`, `style_type`, `style_bg_type`, `style_bg_pattern`, `style_bg_color`, `style_bg_image`, `style_subscribe`, `style_footer`, `style_header`, `style_footer_bg`, `style_preload`, `css`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'BAŞ SAHYPA', 'BAŞ SAHYPA', 'BAŞ SAHYPA', 'Заголовок сайта', 'Pagina Titel', 'Website description and some little information about it', 'Описание веб-сайта и небольшая информация о нем', 'Beschrijving van de website en wat informatie erover', NULL, NULL, 'key, words, website, web', '关键，词，网站，网络', 'clave, palabras, sitio web, web', 'ключ, слова, веб-сайт, веб', 'clé, mots, site web, web', 'sleutel, woorden, website, web', NULL, NULL, 'info@sitename.com', 1, 1, 1, 0, 0, 'http://www.sitename.com/', 1, 'Website under maintenance \r\n<h1>Comming SOON</h1>', '#', '#', NULL, '#', '#', '#', '#', '#', '#', '#', 'Building, Street name, City, Country', '建筑物、街道名称、城市、国家', 'Edificio, Nombre de la calle, Ciudad, País', 'Здание, Название улицы, Город, Страна', 'Bâtiment, Nom de rue, Ville, Pays', 'Gebouw, straatnaam, plaats, land', NULL, NULL, '+(xxx) 0xxxxxxx', '+(xxx) 0xxxxxxx', '+(xxx) 0xxxxxxx', NULL, 'Sunday to Thursday 08:00 AM to 05:00 PM', '周日至周四 08:00 AM 至 05:00 PM', 'Domingo a jueves 08:00 AM a 05:00 PM', 'С воскресенья по четверг с 08:00 до 17:00.', 'Du dimanche au jeudi de 08h00 à 17h00', 'zondag t/m donderdag 08:00 uur tot 17:00 uur', NULL, NULL, '16598986867489.png', NULL, NULL, '16598986868570.png', NULL, NULL, '16599067454085.png', '16599067459701.png', NULL, NULL, '#5a6967', '#2e3e4e', 0, 0, NULL, NULL, NULL, 0, 1, 1, NULL, 1, NULL, 1, 1, '2022-08-07 13:02:33', '2022-08-07 21:15:12');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_topics`
--

CREATE TABLE `smartend_topics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_en` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tk` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tr` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_ru` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_fr` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_de` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `video_type` tinyint(4) DEFAULT NULL,
  `photo_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attach_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_file` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `visits` int(11) NOT NULL,
  `webmaster_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `row_no` int(11) NOT NULL,
  `form_id` int(11) DEFAULT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `seo_title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_topics`
--

INSERT INTO `smartend_topics` (`id`, `title_en`, `title_tk`, `title_tr`, `title_ru`, `title_fr`, `title_de`, `details_en`, `details_tk`, `details_tr`, `details_ru`, `details_fr`, `details_de`, `date`, `expire_date`, `video_type`, `photo_file`, `attach_file`, `video_file`, `audio_file`, `icon`, `status`, `visits`, `webmaster_id`, `section_id`, `row_no`, `form_id`, `topic_id`, `seo_title_en`, `seo_title_tr`, `seo_title_tk`, `seo_title_ru`, `seo_title_fr`, `seo_title_de`, `seo_description_en`, `seo_description_tr`, `seo_description_tk`, `seo_description_ru`, `seo_description_fr`, `seo_description_de`, `seo_keywords_en`, `seo_keywords_tr`, `seo_keywords_tk`, `seo_keywords_ru`, `seo_keywords_fr`, `seo_keywords_de`, `seo_url_slug_en`, `seo_url_slug_tr`, `seo_url_slug_tk`, `seo_url_slug_ru`, `seo_url_slug_fr`, `seo_url_slug_de`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'About Us', '关于', 'Acerca de', 'О', 'À propos', 'Over', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', '2022-08-07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 6, 1, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-08-07 13:02:35', '2022-08-13 17:08:03'),
(2, 'Contact Us', '接触', 'Contacto', 'Контакт', 'Contact', 'Contact', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', '2022-08-07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 7, 1, 0, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-08-07 13:02:35', '2022-08-10 09:56:07'),
(3, 'Privacy', '隐私', 'Intimidad', 'Конфиденциальность', 'Intimité', 'Privacy', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', '2022-08-07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 2, 1, 0, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-08-07 13:02:35', '2022-08-08 03:34:06'),
(4, 'Terms & Conditions', '条款和条件', 'Términos y condiciones', 'Условия и положения', 'termes et conditions', 'algemene voorwaarden', 'It is a long established fact that a reader will be distracted by the readable content of a page.', '一个长期存在的事实是，读者会被页面的可读内容分散注意力。', 'Es un hecho establecido desde hace mucho tiempo que un lector se distraerá con el contenido legible de una página.', 'Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы.', 'C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.', 'Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.', '2022-08-07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 2, 1, 0, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-08-07 13:02:35', '2022-08-08 03:34:06'),
(5, 'Home Welcome', 'test', 'test', 'Дом', 'Domicile', 'Thuis', '<div style=\'text-align: center\'><h2>Welcome to our website</h2>It is a long established fact that a reader will be distracted by the readable content of a page.It is a long established fact that a reader will be distracted by the readable content of a page.It is a long established fact that a reader will be distracted by the readable content of a page.It is a long established fact that a reader will be distracted by the readable content of a page.It is a long established fact that a reader will be distracted by the readable content of a page.</div>', '<p>test</p>', '<p>test</p>', '<div style=\'text-align: center\'><h2>Добро пожаловать на наш сайт</h2>То, что читатель будет отвлекаться на удобочитаемое содержание страницы, - давно установленный факт. То, что читатель будет отвлекаться на читаемое содержание страницы, - давно установленный факт. отвлекаться на читабельное содержание страницы. Давно установлено, что читатель будет отвлекаться на читабельное содержание страницы. Давно установившийся факт, что читатель будет отвлекаться на читаемое содержание страницы.</div>', '<div style=\'text-align: center\'><h2>Bienvenue sur notre site</h2>C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.C\'est un fait établi de longue date qu\'un lecteur être distrait par le contenu lisible d\'une page. C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page. C\'est un fait établi de longue date qu\'un lecteur sera distrait par le contenu lisible d\'une page.</div>', '<div style=\'text-align: center\'><h2>Welkom op onze website</h2>Het staat al lang vast dat een lezer wordt afgeleid door de leesbare inhoud van een pagina. Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina. worden afgeleid door de leesbare inhoud van een pagina. Het staat al lang vast dat een lezer wordt afgeleid door de leesbare inhoud van een pagina. Het is een vaststaand feit dat een lezer wordt afgeleid door de leesbare inhoud van een pagina.</div>', '2022-08-07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 0, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '2022-08-07 13:02:35', '2022-08-07 15:46:04'),
(6, 'Water', 'Agyzsuw', NULL, 'Voda', NULL, NULL, '<div dir=\"ltr\">Water payments&nbsp; &nbsp;</div>', '<div dir=\"ltr\">Agyzsuw tölegi</div>', NULL, '<div dir=\"ltr\">Voda</div>', NULL, NULL, '2022-08-08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, 2, 0, 1, NULL, NULL, 'Water', NULL, 'Agyzsuw', 'Voda', NULL, NULL, 'Water payments&nbsp; &nbsp;', NULL, 'Agyzsuw tölegi', 'Voda', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'water', NULL, 'agyzsuw', 'voda', NULL, NULL, 1, NULL, '2022-08-08 03:57:54', '2022-08-16 04:25:32'),
(7, 'Water blogpost', 'Agyzsuw habar', NULL, 'Вода блогпост', NULL, NULL, '<div dir=\"ltr\">Water blogpost<br></div>', '<div dir=\"ltr\">Agyzsuw habar<br></div>', NULL, '<div dir=\"ltr\">Вода блогпост<br></div>', NULL, NULL, '2022-08-08', NULL, NULL, '16599365585153.jpg', NULL, NULL, NULL, NULL, 1, 2, 7, 0, 1, NULL, NULL, 'Water blogpost', NULL, 'Agyzsuw habar', 'Вода блогпост', NULL, NULL, 'Water blogpost', NULL, 'Agyzsuw habar', 'Вода блогпост', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'water-blogpost', NULL, 'agyzsuw-habar', 'voda-blogpost', NULL, NULL, 1, NULL, '2022-08-08 04:29:18', '2022-08-08 04:29:57'),
(8, 'Test en', 'test tm', NULL, 'test  ru', NULL, NULL, '<div dir=\"ltr\">test habar en&nbsp;&nbsp;&nbsp;&nbsp;</div>', '<div dir=\"ltr\">test habar tm</div>', NULL, '<div dir=\"ltr\">test habr ru</div>', NULL, NULL, '2022-08-10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 2, 7, 0, 2, NULL, NULL, 'Test en', NULL, 'test tm', 'test  ru', NULL, NULL, 'test habar en&nbsp;&nbsp;&nbsp;&nbsp;', NULL, 'test habar tm', 'test habr ru', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test-en', NULL, 'test-tm', 'test-ru', NULL, NULL, 1, NULL, '2022-08-10 09:36:57', '2022-08-13 15:52:25');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_topic_categories`
--

CREATE TABLE `smartend_topic_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_topic_categories`
--

INSERT INTO `smartend_topic_categories` (`id`, `topic_id`, `section_id`, `created_at`, `updated_at`) VALUES
(1, 7, 1, '2022-08-08 04:29:18', '2022-08-08 04:29:18'),
(2, 8, 1, '2022-08-10 09:36:57', '2022-08-10 09:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_topic_fields`
--

CREATE TABLE `smartend_topic_fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `topic_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `field_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_users`
--

CREATE TABLE `smartend_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `connect_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connect_password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_users`
--

INSERT INTO `smartend_users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `photo`, `permissions_id`, `status`, `connect_email`, `connect_password`, `provider`, `provider_id`, `access_token`, `created_by`, `updated_by`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@elipbiy01.com', NULL, '$2y$10$/D0sgtix9M1HP6hDyYic7u2n6dS.FyTkb7KlttO3seD9vFskEhuQa', NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, 1, NULL, 'ENYgKwfHxybJWh7bICLUhF01JAYr4qYhZfjhWIWuoGMJV6WNSPwffnMzJ7Ty', NULL, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_webmails`
--

CREATE TABLE `smartend_webmails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` int(11) NOT NULL DEFAULT 0,
  `group_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `father_id` int(11) DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL,
  `from_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_cc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_bcc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `flag` tinyint(4) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_webmails_files`
--

CREATE TABLE `smartend_webmails_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `webmail_id` int(11) NOT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_webmails_groups`
--

CREATE TABLE `smartend_webmails_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_webmails_groups`
--

INSERT INTO `smartend_webmails_groups` (`id`, `name`, `color`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Support', '#00bcd4', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(2, 'Orders', '#f44336', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35'),
(3, 'Queries', '#8bc34a', 1, NULL, '2022-08-07 13:02:35', '2022-08-07 13:02:35');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_webmaster_banners`
--

CREATE TABLE `smartend_webmaster_banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `row_no` int(11) NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `desc_status` tinyint(4) NOT NULL,
  `link_status` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `icon_status` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_webmaster_banners`
--

INSERT INTO `smartend_webmaster_banners` (`id`, `row_no`, `title_en`, `title_tr`, `title_tk`, `title_ru`, `title_fr`, `title_de`, `width`, `height`, `desc_status`, `link_status`, `type`, `icon_status`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Home Banners', NULL, NULL, NULL, NULL, NULL, 1600, 500, 1, 1, 1, 0, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(2, 2, 'Text Banners', NULL, NULL, NULL, NULL, NULL, 330, 330, 1, 1, 0, 1, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(3, 3, 'Side Banners', NULL, NULL, NULL, NULL, NULL, 330, 330, 0, 1, 1, 0, 1, 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_webmaster_sections`
--

CREATE TABLE `smartend_webmaster_sections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `row_no` int(11) NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 0,
  `title_status` tinyint(4) NOT NULL DEFAULT 1,
  `photo_status` tinyint(4) NOT NULL DEFAULT 1,
  `case_status` tinyint(4) NOT NULL DEFAULT 1,
  `visits_status` tinyint(4) NOT NULL DEFAULT 1,
  `sections_status` tinyint(4) NOT NULL DEFAULT 0,
  `comments_status` tinyint(4) NOT NULL DEFAULT 0,
  `date_status` tinyint(4) NOT NULL DEFAULT 0,
  `expire_date_status` tinyint(4) NOT NULL DEFAULT 0,
  `longtext_status` tinyint(4) NOT NULL DEFAULT 0,
  `editor_status` tinyint(4) NOT NULL DEFAULT 0,
  `attach_file_status` tinyint(4) NOT NULL DEFAULT 0,
  `extra_attach_file_status` tinyint(4) NOT NULL DEFAULT 0,
  `multi_images_status` tinyint(4) NOT NULL DEFAULT 0,
  `section_icon_status` tinyint(4) NOT NULL DEFAULT 0,
  `icon_status` tinyint(4) NOT NULL DEFAULT 0,
  `maps_status` tinyint(4) NOT NULL DEFAULT 0,
  `order_status` tinyint(4) NOT NULL DEFAULT 0,
  `related_status` tinyint(4) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `seo_title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_url_slug_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_webmaster_sections`
--

INSERT INTO `smartend_webmaster_sections` (`id`, `row_no`, `title_en`, `title_tr`, `title_tk`, `title_ru`, `title_fr`, `title_de`, `type`, `title_status`, `photo_status`, `case_status`, `visits_status`, `sections_status`, `comments_status`, `date_status`, `expire_date_status`, `longtext_status`, `editor_status`, `attach_file_status`, `extra_attach_file_status`, `multi_images_status`, `section_icon_status`, `icon_status`, `maps_status`, `order_status`, `related_status`, `status`, `seo_title_en`, `seo_title_tr`, `seo_title_tk`, `seo_title_ru`, `seo_title_fr`, `seo_title_de`, `seo_description_en`, `seo_description_tr`, `seo_description_tk`, `seo_description_ru`, `seo_description_fr`, `seo_description_de`, `seo_keywords_en`, `seo_keywords_tr`, `seo_keywords_tk`, `seo_keywords_ru`, `seo_keywords_fr`, `seo_keywords_de`, `seo_url_slug_en`, `seo_url_slug_tr`, `seo_url_slug_tk`, `seo_url_slug_ru`, `seo_url_slug_fr`, `seo_url_slug_de`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Site pages', '网站页面', 'Sitio Páginas', 'Страницы сайта', 'Site Pages', 'Seiten', 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 'Site pages', '网站页面', 'Sitio Páginas', 'Страницы сайта', 'Site Pages', 'Seiten', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'sitepages', 'sitepages', 'sitepages', 'sitepages', 'sitepages', 'sitepages', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(2, 2, 'Services', '服务', 'Servicios', 'Услуги', 'services', 'Dienstleistungen', 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 'Services', '服务', 'Servicios', 'Услуги', 'services', 'Dienstleistungen', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'services', 'services', 'services', 'services', 'services', 'services', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(3, 3, 'News', '新闻', 'Noticias', 'Новости', 'Nouvelles', 'Nieuws', 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 'News', '新闻', 'Noticias', 'Новости', 'Nouvelles', 'Nieuws', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'news', 'news', 'news', 'news', 'news', 'news', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(4, 4, 'Photos', '照片', 'Fotos', 'Фото', 'Photos', 'Fotos', 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 'Photos', '照片', 'Fotos', 'Фото', 'Photos', 'Fotos', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'photos', 'photos', 'photos', 'photos', 'photos', 'photos', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(5, 5, 'Videos', '视频', 'Videos', 'Видео', 'Vidéos', 'Videos', 2, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 'Videos', '视频', 'Videos', 'Видео', 'Vidéos', 'Videos', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'videos', 'videos', 'videos', 'videos', 'videos', 'videos', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(6, 6, 'Audio', '声音的', 'Audio', 'Аудио', 'l\'audio', 'Audio', 3, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 'Audio', 'Audio', 'Audio', 'Аудио', 'l\'audio', 'Audio', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'audio', 'audio', 'audio', 'audio', 'audio', 'audio', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(7, 7, 'Blog', '博客', 'Blog', 'Блог', 'Blog', 'Blog', 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 'Blog', '博客', 'Blog', 'Блог', 'Blog', 'Blog', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'blog', 'blog', 'blog', 'blog', 'blog', 'blog', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(8, 8, 'Products', '产品', 'Productos', 'Товары', 'Produits', 'Produkte', 0, 1, 1, 1, 1, 2, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 'Products', '产品', 'Productos', 'Товары', 'Produits', 'Produkte', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'products', 'products', 'products', 'products', 'products', 'products', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33'),
(9, 9, 'Partners', '伙伴', 'Socias', 'Партнеры', 'Les partenaires', 'Partners', 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Partners', '伙伴', 'Socias', 'Партнеры', 'Les partenaires', 'Partners', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'partners', 'partners', 'partners', 'partners', 'partners', 'partners', 1, NULL, '2022-08-07 13:02:33', '2022-08-07 13:02:33');

-- --------------------------------------------------------

--
-- Table structure for table `smartend_webmaster_section_fields`
--

CREATE TABLE `smartend_webmaster_section_fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `webmaster_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `title_en` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_tk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_fr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_de` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_en` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_es` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_tk` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_fr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_de` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row_no` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `required` tinyint(4) NOT NULL,
  `in_table` tinyint(4) NOT NULL DEFAULT 0,
  `in_search` tinyint(4) NOT NULL DEFAULT 0,
  `in_listing` tinyint(4) NOT NULL DEFAULT 0,
  `in_page` tinyint(4) NOT NULL DEFAULT 0,
  `in_statics` tinyint(4) NOT NULL DEFAULT 0,
  `lang_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `css_class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view_permission_groups` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add_permission_groups` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edit_permission_groups` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smartend_webmaster_settings`
--

CREATE TABLE `smartend_webmaster_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `seo_status` tinyint(4) NOT NULL,
  `analytics_status` tinyint(4) NOT NULL,
  `banners_status` tinyint(4) NOT NULL,
  `inbox_status` tinyint(4) NOT NULL,
  `calendar_status` tinyint(4) NOT NULL,
  `settings_status` tinyint(4) NOT NULL,
  `newsletter_status` tinyint(4) NOT NULL,
  `members_status` tinyint(4) NOT NULL,
  `orders_status` tinyint(4) NOT NULL,
  `shop_status` tinyint(4) NOT NULL,
  `shop_settings_status` tinyint(4) NOT NULL,
  `default_currency_id` int(11) NOT NULL,
  `languages_by_default` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latest_news_section_id` int(11) NOT NULL,
  `header_menu_id` int(11) NOT NULL,
  `footer_menu_id` int(11) NOT NULL,
  `home_banners_section_id` int(11) NOT NULL,
  `home_text_banners_section_id` int(11) NOT NULL,
  `side_banners_section_id` int(11) NOT NULL,
  `contact_page_id` int(11) NOT NULL,
  `newsletter_contacts_group` int(11) NOT NULL,
  `new_comments_status` tinyint(4) NOT NULL,
  `links_status` tinyint(4) NOT NULL,
  `register_status` tinyint(4) NOT NULL,
  `permission_group` int(11) NOT NULL,
  `api_status` tinyint(4) NOT NULL,
  `api_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_content1_section_id` int(11) NOT NULL,
  `home_content2_section_id` int(11) NOT NULL,
  `home_content3_section_id` int(11) NOT NULL,
  `home_contents_per_page` int(11) NOT NULL,
  `mail_driver` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_host` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_port` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_encryption` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_no_replay` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_template` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nocaptcha_status` tinyint(4) NOT NULL,
  `nocaptcha_secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nocaptcha_sitekey` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `google_tags_status` tinyint(4) NOT NULL,
  `google_tags_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `google_analytics_code` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_facebook_status` tinyint(4) NOT NULL,
  `login_facebook_client_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_facebook_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_twitter_status` tinyint(4) NOT NULL,
  `login_twitter_client_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_twitter_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_google_status` tinyint(4) NOT NULL,
  `login_google_client_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_google_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_linkedin_status` tinyint(4) NOT NULL,
  `login_linkedin_client_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_linkedin_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_github_status` tinyint(4) NOT NULL,
  `login_github_client_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_github_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_bitbucket_status` tinyint(4) NOT NULL,
  `login_bitbucket_client_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_bitbucket_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dashboard_link_status` tinyint(4) NOT NULL,
  `text_editor` tinyint(4) NOT NULL DEFAULT 0,
  `tiny_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smartend_webmaster_settings`
--

INSERT INTO `smartend_webmaster_settings` (`id`, `seo_status`, `analytics_status`, `banners_status`, `inbox_status`, `calendar_status`, `settings_status`, `newsletter_status`, `members_status`, `orders_status`, `shop_status`, `shop_settings_status`, `default_currency_id`, `languages_by_default`, `latest_news_section_id`, `header_menu_id`, `footer_menu_id`, `home_banners_section_id`, `home_text_banners_section_id`, `side_banners_section_id`, `contact_page_id`, `newsletter_contacts_group`, `new_comments_status`, `links_status`, `register_status`, `permission_group`, `api_status`, `api_key`, `home_content1_section_id`, `home_content2_section_id`, `home_content3_section_id`, `home_contents_per_page`, `mail_driver`, `mail_host`, `mail_port`, `mail_username`, `mail_password`, `mail_encryption`, `mail_no_replay`, `mail_title`, `mail_template`, `nocaptcha_status`, `nocaptcha_secret`, `nocaptcha_sitekey`, `google_tags_status`, `google_tags_id`, `google_analytics_code`, `login_facebook_status`, `login_facebook_client_id`, `login_facebook_client_secret`, `login_twitter_status`, `login_twitter_client_id`, `login_twitter_client_secret`, `login_google_status`, `login_google_client_id`, `login_google_client_secret`, `login_linkedin_status`, `login_linkedin_client_id`, `login_linkedin_client_secret`, `login_github_status`, `login_github_client_id`, `login_github_client_secret`, `login_bitbucket_status`, `login_bitbucket_client_id`, `login_bitbucket_client_secret`, `dashboard_link_status`, `text_editor`, `tiny_key`, `timezone`, `version`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 'en', 3, 1, 2, 1, 2, 3, 2, 1, 1, 0, 0, 3, 0, '402784613679330', 7, 4, 9, 20, 'smtp', '', '', '', '', '', '', '{title}', '{details}', 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '', '', 1, 0, NULL, 'UTC', '8.6.0', 1, 1, '2022-08-07 13:02:33', '2022-08-07 14:43:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `smartend_analytics_pages`
--
ALTER TABLE `smartend_analytics_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_analytics_visitors`
--
ALTER TABLE `smartend_analytics_visitors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_attach_files`
--
ALTER TABLE `smartend_attach_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_banners`
--
ALTER TABLE `smartend_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_comments`
--
ALTER TABLE `smartend_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_contacts`
--
ALTER TABLE `smartend_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_contacts_groups`
--
ALTER TABLE `smartend_contacts_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_countries`
--
ALTER TABLE `smartend_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_events`
--
ALTER TABLE `smartend_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_failed_jobs`
--
ALTER TABLE `smartend_failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `smartend_failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `smartend_languages`
--
ALTER TABLE `smartend_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_maps`
--
ALTER TABLE `smartend_maps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_menus`
--
ALTER TABLE `smartend_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_migrations`
--
ALTER TABLE `smartend_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_password_resets`
--
ALTER TABLE `smartend_password_resets`
  ADD KEY `smartend_password_resets_email_index` (`email`);

--
-- Indexes for table `smartend_permissions`
--
ALTER TABLE `smartend_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_photos`
--
ALTER TABLE `smartend_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_related_topics`
--
ALTER TABLE `smartend_related_topics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_sections`
--
ALTER TABLE `smartend_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_sessions`
--
ALTER TABLE `smartend_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `smartend_sessions_user_id_index` (`user_id`),
  ADD KEY `smartend_sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `smartend_settings`
--
ALTER TABLE `smartend_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_topics`
--
ALTER TABLE `smartend_topics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_topic_categories`
--
ALTER TABLE `smartend_topic_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_topic_fields`
--
ALTER TABLE `smartend_topic_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_users`
--
ALTER TABLE `smartend_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `smartend_users_email_unique` (`email`);

--
-- Indexes for table `smartend_webmails`
--
ALTER TABLE `smartend_webmails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_webmails_files`
--
ALTER TABLE `smartend_webmails_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_webmails_groups`
--
ALTER TABLE `smartend_webmails_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_webmaster_banners`
--
ALTER TABLE `smartend_webmaster_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_webmaster_sections`
--
ALTER TABLE `smartend_webmaster_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_webmaster_section_fields`
--
ALTER TABLE `smartend_webmaster_section_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smartend_webmaster_settings`
--
ALTER TABLE `smartend_webmaster_settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `smartend_analytics_pages`
--
ALTER TABLE `smartend_analytics_pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;

--
-- AUTO_INCREMENT for table `smartend_analytics_visitors`
--
ALTER TABLE `smartend_analytics_visitors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `smartend_attach_files`
--
ALTER TABLE `smartend_attach_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_banners`
--
ALTER TABLE `smartend_banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `smartend_comments`
--
ALTER TABLE `smartend_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `smartend_contacts`
--
ALTER TABLE `smartend_contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_contacts_groups`
--
ALTER TABLE `smartend_contacts_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `smartend_countries`
--
ALTER TABLE `smartend_countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `smartend_events`
--
ALTER TABLE `smartend_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_failed_jobs`
--
ALTER TABLE `smartend_failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_languages`
--
ALTER TABLE `smartend_languages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `smartend_maps`
--
ALTER TABLE `smartend_maps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_menus`
--
ALTER TABLE `smartend_menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `smartend_migrations`
--
ALTER TABLE `smartend_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `smartend_permissions`
--
ALTER TABLE `smartend_permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `smartend_photos`
--
ALTER TABLE `smartend_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_related_topics`
--
ALTER TABLE `smartend_related_topics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_sections`
--
ALTER TABLE `smartend_sections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `smartend_settings`
--
ALTER TABLE `smartend_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `smartend_topics`
--
ALTER TABLE `smartend_topics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `smartend_topic_categories`
--
ALTER TABLE `smartend_topic_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `smartend_topic_fields`
--
ALTER TABLE `smartend_topic_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_users`
--
ALTER TABLE `smartend_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `smartend_webmails`
--
ALTER TABLE `smartend_webmails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_webmails_files`
--
ALTER TABLE `smartend_webmails_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_webmails_groups`
--
ALTER TABLE `smartend_webmails_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `smartend_webmaster_banners`
--
ALTER TABLE `smartend_webmaster_banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `smartend_webmaster_sections`
--
ALTER TABLE `smartend_webmaster_sections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `smartend_webmaster_section_fields`
--
ALTER TABLE `smartend_webmaster_section_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smartend_webmaster_settings`
--
ALTER TABLE `smartend_webmaster_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
