

Designed for those who like bold elements and beautiful websites. Made of hundred of elements, designed blocks, and fully coded pages, Soft UI Dashboard PRO is ready to help you create stunning websites and web apps.

We created many examples for pages like Sign In, Profile, and so on. Just choose between a Basic Design, an illustration, or a cover and you are good to go!

**Fully Coded Elements**

Soft UI Dashboard PRO is built with over 300 frontend individual elements, like buttons, inputs, navbars, nav tabs, cards, or alerts, giving you the freedom of choosing and combining. All components can take variations in color, which you can easily modify using SASS files and classes.

You will save a lot of time going from prototyping to full-functional code because all elements are implemented.  

This Premium Bootstrap 5 Dashboard is coming with prebuilt design blocks, so the development process is seamless,  
switching from our pages to the real website is very easy to be done.




#### Special thanks

During the development of this dashboard, we have used many existing resources from awesome developers. We want to thank them for providing their tools open source:

-   [noUISlider](https://refreshless.com/nouislider/) - JavaScript Range Slider
-   [Popper.js](https://popper.js.org/) - Kickass library used to manage poppers
-   [Flatpickr](https://flatpickr.js.org/) - Useful library used to select date
-   [Choices JS](https://joshuajohnson.co.uk/Choices/) - A nice plugin that select elements with intuitive multiselection and searching but also for managing tags.
-   [CountUp JS](https://inorganik.github.io/countUp.js/) - A dependency-free, lightweight JavaScript class that can be used to quickly create animations that display numerical data in a more interesting way.
-   [Charts Js](https://www.chartjs.org/) - Simple yet flexible JavaScript charting for designers & developers
-   [FullCalendar](https://fullcalendar.io/) - Full-sized drag & drop event calendar
-   [Dropzone](https://www.dropzonejs.com/) - An open source library that provides drag’n’drop file uploads with image previews.
-   [Datatables](https://github.com/fiduswriter/Simple-DataTables) - DataTables but in Vanilla ES2018 JS
-   [jKanban](http://www.riccardotartaglia.it/jkanban/) - Pure agnostic Javascript plugin for Kanban boards
-   [PhotoSwipe](https://photoswipe.com/) - JavaScript image gallery for mobile and desktop, modular, framework independent
-   [Quill](https://quilljs.com/) - A free, open source WYSIWYG editor built for the modern web
-   [Sweet Alerts](https://sweetalert2.github.io/) - A beautiful, responsive, customisable, accessible replacement for Javascript’s popup boxes.
-   [three.js](https://threejs.org/) - JavaScript 3D library
-   [Wizard](https://www.cssscript.com/multi-step-form-bootstrap/) - Animated Multi-step form for Bootstrap

Let us know your thoughts below. And good luck with development!

## Table of Contents

-   [Versions](#versions)
-   [Demo](#demo)
-   [Quick Start](#quick-start)
-   [Documentation](#documentation)
-   [File Structure](#file-structure)
-   [Browser Support](#browser-support)
-   [Resources](#resources)
-   [Reporting Issues](#reporting-issues)
-   [Technical Support or Questions](#technical-support-or-questions)
-   [Licensing](#licensing)
-   [Useful Links](#useful-links)





## Terminal Commands

1.  Download and Install NodeJs from [NodeJs Official Page](https://nodejs.org/en/download/).
2.  Navigate to the root / directory and run npm install to install our local dependencies.



### What's included

Within the download you'll find the following directories and files:

  soft-ui-dashboard-pro
    ├── assets
    │   ├── css
    │   ├── fonts
    │   ├── img
    │   ├── js
    │   │   ├── core
    │   │   ├── plugins
    │   │   └── points.json
    │   │   └── soft-ui-dashboard.min.js
    │   └── scss
    │       ├── soft-ui-dashboard-pro
    │       └── soft-ui-dashboard.scss
    ├── docs
    │   ├── documentation.html
    ├── pages
    │   ├── applications
    │   ├── authentication
    │   ├── dashboards
    │   ├── ecommerce
    │   ├── pages
    ├── CHANGELOG.md
    ├── gulpfile.js
    ├── package.json
    ├── presentation.html

